/********************************************************************
 ************ COPYRIGHT (c) 2016 by ke0ff, Taylor, TX   *************
 *
 *  File name: tiva_init.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  Tiva processor init functions
 *
 *******************************************************************/

#include <stdint.h>
#include <stdio.h>
#include <ctype.h>
#include "inc/tm4c123gh6pm.h"
#include "typedef.h"
#include "init.h"						// App-specific SFR Definitions
#include "tiva_init.h"
#include "adc.h"
#include "serial.h"
#include "PLL.h"
#include "eeprom.h"
#include "pwm.h"

#include "version.h"

//=============================================================================
// local registers


//=============================================================================
// local Fn declarations


//*****************************************************************************
// proc_init()
//  initializes the processor I/O peripherals
//	returns bitmapped initialize result status as U16
//
//*****************************************************************************
U16 proc_init(void){
	volatile uint32_t ui32Loop;
//	volatile uint32_t ii;
	U16	ipl;					// initialize response value
//	uint32_t i;

	// init UARTs
	SYSCTL_RCGCGPIO_R = PORTA;
	GPIO_PORTA_DATA_R = PORTA_DFLT;
	GPIO_PORTA_DIR_R = PORTA_DIRV;
	GPIO_PORTA_DEN_R = PORTA_DENV;
	GPIO_PORTA_PUR_R = PORTA_PURV;
	GPIO_PORTA_DATA_R = PORTA_DFLT;
	initserial();						// init UART0-2
//	process_xrx(RX_STATE_CLEAR);		// init xmodem receive
	NVIC_EN0_R = NVIC_EN0_UART0|NVIC_EN0_UART1;				// enable UART0 & UART1 intr
	ipl = IPL_UART0INIT;
	ipl |= IPL_UART1INIT;

	// init PLL
	PLL_Init(SYSCLK);
	// init HIB module...disabled in this app
	hib_init(0);

	// Enable the GPIO port clocks.
	SYSCTL_RCGCGPIO_R = PORTF|PORTE|PORTD|PORTC|PORTB|PORTA;

	// Do a dummy read to insert a few cycles after enabling the peripheral.
	ui32Loop = SYSCTL_RCGCGPIO_R;

	// Enable the GPIO pins.
	GPIO_PORTF_LOCK_R = 0x4C4F434B;										// unlock PORTF
	GPIO_PORTF_CR_R = 0xff;
	GPIO_PORTF_DIR_R = PORTF_DIRV;
	GPIO_PORTF_DEN_R = PORTF_DENV;
	GPIO_PORTF_AFSEL_R = 0;
	GPIO_PORTE_DIR_R = PORTE_DIRV;
	GPIO_PORTE_DEN_R = PORTE_DENV;
	GPIO_PORTE_PUR_R = PORTE_PURV;
	GPIO_PORTD_LOCK_R = 0x4C4F434B;										// unlock PORTD
	GPIO_PORTD_CR_R = 0xff;
	GPIO_PORTD_DIR_R = PORTD_DIRV;
	GPIO_PORTD_DEN_R = PORTD_DENV;
	GPIO_PORTD_PUR_R = PORTD_PURV;
	GPIO_PORTC_DIR_R &= 0x0f;											// preserve JTAG pin assignments
	GPIO_PORTC_DEN_R &= 0x0f;
	GPIO_PORTC_DIR_R |= (PORTC_DIRV & 0xf0);
	GPIO_PORTC_DEN_R |= (PORTC_DENV & 0xf0);
	GPIO_PORTB_DIR_R = PORTB_DIRV;										//0x32
	GPIO_PORTB_DEN_R = PORTB_DENV;										//0xb0;
	GPIO_PORTB_PUR_R = PORTB_PURV;

	GPIO_PORTF_DATA_R = 0x00;
	GPIO_PORTE_DATA_R = 0x00;
	GPIO_PORTD_DATA_R = 0x00;
	GPIO_PORTC_DATA_R = 0x00;
	GPIO_PORTB_DATA_R = 0x00;
//	GPIO_PORTA_DATA_R = (NANTDN|N6MON|NUHFON);
	encoder_init();

	// init timer3A (IC, edge time mode, with ISR -- inputs HM-151 data pulses)
	SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R3;
	ui32Loop = SYSCTL_RCGCTIMER_R;
	TIMER3_CTL_R &= ~TIMER_CTL_TAEN;									// disable timer
	GPIO_PORTB_PCTL_R &= ~(GPIO_PCTL_PB2_M);
	GPIO_PORTB_PCTL_R |= (GPIO_PCTL_PB2_T3CCP0);
	GPIO_PORTB_AFSEL_R |= MDATA4;
	TIMER3_CFG_R = TIMER_CFG_16_BIT;									// 16 bit timer mode
	TIMER3_CTL_R &= ~TIMER_CTL_TAEVENT_M;								// mask edge mode
	TIMER3_CTL_R |= TIMER_CTL_TAEVENT_POS;								// do RET capture
	TIMER3_TAMR_R &= ~(TIMER_TAMR_TAMR_M);								// set capture mode, count up, edge time
	TIMER3_TAMR_R |= (TIMER_TAMR_TACMR | TIMER_TAMR_TAMR_CAP | TIMER_TAMR_TACDIR);
	TIMER3_TAMATCHR_R = 0xffffffff;										// no match value
	TIMER3_TAPMR_R = 0xff;
	TIMER3_IMR_R |= TIMER_IMR_CAEIM;									// enable capture interrupt
	TIMER3_TAILR_R = TIMER3_ILR;													// clear load regs
	TIMER3_TAPR_R = TIMER3_PS;
	ui32Loop = TIMER3_ICR_R;
	TIMER3_CTL_R |= (TIMER_CTL_TAEN);									// enable timer
	TIMER3_ICR_R = TIMER_ICR_CAECINT;									// pre-clear spurious int flag
	NVIC_EN1_R = NVIC_EN1_TIMER3A;										// enable timer intr in the NVIC
	ipl |= IPL_TIMER3INIT;

	// init timer1A, fan opr IC
/*	SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R1;
	ui32Loop = SYSCTL_RCGCTIMER_R;
	TIMER1_CTL_R &= ~TIMER_CTL_TAEN;									// disable timer
	GPIO_PORTB_PCTL_R &= ~(GPIO_PCTL_PB4_M);							// PB4 = port pin for IC
	GPIO_PORTB_PCTL_R |= (GPIO_PCTL_PB4_T1CCP0);
	GPIO_PORTB_AFSEL_R |= NFANOPR;
	TIMER1_CFG_R = 0x04;												// 16 bit timer mode
	TIMER1_CTL_R |= TIMER_CTL_TAEVENT_NEG;								// capture falling edges only
	TIMER1_TAMR_R &= ~(TIMER_TAMR_TAMR_M);								// set capture mode, count up, edge time
	TIMER1_TAMR_R |= (TIMER_TAMR_TACMR | TIMER_TAMR_TAMR_CAP | TIMER_TAMR_TACDIR);
	TIMER1_TAMATCHR_R = 0xffffffff;										// no match value
	TIMER1_TAPMR_R = 0xff;
	TIMER1_TAPR_R = TIMER1_PS - 1;										// prescale reg = divide ratio - 1
	TIMER1_TAILR_R = 0xffffffff;
	TIMER1_IMR_R |= TIMER_IMR_CAEIM;									// enable capture interrupt
	TIMER1_TAILR_R = 0;													// clear load regs
	ui32Loop = TIMER1_ICR_R;
	TIMER1_CTL_R |= (TIMER_CTL_TAEN);									// enable timer
	TIMER1_ICR_R = TIMER_ICR_CAECINT;									// pre-clear spurious int flag
	NVIC_EN0_R = 0x00200000L;											// enable timer intr in the NVIC
	ipl |= IPL_TIMER1INIT;*/

	/*	SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R0;
	ui32Loop = SYSCTL_RCGCTIMER_R;
	TIMER0_CTL_R = 0;													// disable timer, do RET capture
	GPIO_PORTB_PCTL_R &= ~(GPIO_PCTL_PB6_M);
	GPIO_PORTB_PCTL_R |= (GPIO_PCTL_PB6_T0CCP0);
	GPIO_PORTB_AFSEL_R |= T0P0;
	TIMER0_CFG_R = 0x04;
	TIMER0_TAMR_R &= ~(TIMER_TAMR_TACMR | TIMER_TAMR_TAMR_M);			// set capture mode, count up
	TIMER0_TAMR_R |= (TIMER_TAMR_TAMR_CAP | TIMER_TAMR_TACDIR);
	TIMER0_TAMATCHR_R = 0xffffffff;										// no match value
	TIMER0_TAPMR_R = 0xff;
	TIMER0_ICR_R = TIMER_ICR_CAECINT;
	ui32Loop = TIMER0_ICR_R;
	TIMER0_CTL_R |= (TIMER_CTL_TAEN);									// enable timer
*/
//	TIMER0_ICR_R = TIMER0_MIS_R;
//	NVIC_EN0_R = 0x00080000L;											// enable timer intr in the NVIC

	// init timer1A (serial pacing timer, count down, no GPIO)
	SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R1;
	ui32Loop = SYSCTL_RCGCGPIO_R;
	TIMER1_CTL_R &= ~(TIMER_CTL_TAEN);				// disable timer
	TIMER1_CFG_R = TIMER_CFG_16_BIT; //0x4; //0;
	TIMER1_TAMR_R = TIMER_TAMR_TAMR_PERIOD;
	TIMER1_TAPR_R = TIMER1_PS;
	TIMER1_TAILR_R = (uint16_t)(SYSCLK/(TIMER1_FREQ * (TIMER1_PS + 1)));
	TIMER1_IMR_R = TIMER_IMR_TATOIM;				// enable timer intr
	TIMER1_CTL_R |= (TIMER_CTL_TAEN);				// enable timer
	TIMER1_ICR_R = TIMER1_MIS_R;					// clear any flagged ints
	NVIC_EN0_R = NVIC_EN0_TIMER1A;					// enable timer1A intr in the NVIC_EN regs
	ipl = IPL_TIMER1INIT;

	// init timer2A (appl timer, count down, no GPIO)
	SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R2;
	ui32Loop = SYSCTL_RCGCTIMER_R;
	TIMER2_CTL_R &= ~(TIMER_CTL_TAEN);									// disable timer
	TIMER2_CFG_R = 0x4;
	TIMER2_TAMR_R = TIMER_TAMR_TAMR_PERIOD;
	TIMER2_TAPR_R = (TIMER2_PS - 1);									// prescale reg = divide ratio - 1
	TIMER2_TAILR_R = (uint16_t)(SYSCLK/(1000 * TIMER2_PS));
	TIMER2_IMR_R = TIMER_IMR_TATOIM;									// enable timer intr
	TIMER2_CTL_R |= (TIMER_CTL_TAEN);									// enable timer
	TIMER2_ICR_R = TIMER2_MIS_R;
	NVIC_EN0_R = NVIC_EN0_TIMER2A;										// enable timer intr in the NVIC
	ipl = IPL_TIMER2INIT;

	// init comparators (PC4-7, PF0)
/*	SYSCTL_RCGCACMP_R = SYSCTL_RCGCACMP_R0;
	ui32Loop = SYSCTL_RCGCACMP_R;										// delay a few cycles
	GPIO_PORTF_PCTL_R &= ~GPIO_PCTL_PF0_M;								// config CP0 output on PF0
	GPIO_PORTF_PCTL_R |= GPIO_PCTL_PF0_C0O;
	GPIO_PORTF_AFSEL_R |= C0D;
	COMP_ACREFCTL_R = 0;												// disable internal comparator ref
//COMP_ACSTAT0_R == COMP_ACSTAT1_OVAL	// comparator output value test
	COMP_ACCTL0_R = COMP_ACCTL0_ASRCP_PIN;								// C0 uses C0+ pin
	COMP_ACCTL1_R = COMP_ACCTL1_ASRCP_PIN;	*/							// C1 uses C1+ pin

	// init PWMs on PF0-3 (LED3:LED6), PE4-5 (LED1:LED2)


/*	SYSCTL_RCGCPWM_R |= SYSCTL_RCGCPWM_R1;
	ui32Loop = SYSCTL_RCGCPWM_R;										// delay a few cycles
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R5 | SYSCTL_RCGCGPIO_R4;
	ui32Loop = SYSCTL_RCGCGPIO_R;										// delay a few cycles
	GPIO_PORTF_AFSEL_R |= LED3|LED4|LED5|LED6;							// enable alt fn, PF1-3
	GPIO_PORTF_PCTL_R &= ~(GPIO_PCTL_PF3_M|GPIO_PCTL_PF2_M|GPIO_PCTL_PF1_M|GPIO_PCTL_PF0_M);
	GPIO_PORTF_PCTL_R |= (GPIO_PCTL_PF3_M1PWM7|GPIO_PCTL_PF2_M1PWM6|GPIO_PCTL_PF1_M1PWM5|GPIO_PCTL_PF0_M1PWM4);
	GPIO_PORTE_AFSEL_R |= LED1|LED2;									// enable alt fn, PE4-5
	GPIO_PORTE_PCTL_R &= ~(GPIO_PCTL_PE5_M|GPIO_PCTL_PE4_M);
	GPIO_PORTE_PCTL_R |= (GPIO_PCTL_PE5_M1PWM3|GPIO_PCTL_PE4_M1PWM2);
	SYSCTL_RCC_R = (SYSCTL_RCC_R & ~SYSCTL_RCC_PWMDIV_M) | (PWM_DIV << 17) | SYSCTL_RCC_USEPWMDIV;
	PWM1_1_CTL_R = 0;
	PWM1_1_GENA_R = PWM_1_GENA_ACTCMPAD_ZERO|PWM_1_GENA_ACTLOAD_ONE;	//0x8c;
	PWM1_1_GENB_R = PWM_1_GENB_ACTCMPBD_ZERO|PWM_1_GENB_ACTLOAD_ONE;	//0x80c;
	PWM1_1_LOAD_R = PWM_ZERO;											// 4KHz at SYSCLK = 16MHz (2000-1);
	PWM1_1_CMPA_R = PWM_ZERO - 1;										//1900;
	PWM1_1_CMPB_R = PWM_ZERO - 1;										//1900;
	PWM1_2_CTL_R = 0;
	PWM1_2_GENA_R = PWM_2_GENA_ACTCMPAD_ZERO|PWM_2_GENA_ACTLOAD_ONE;	//0x80c;
	PWM1_2_GENB_R = PWM_2_GENB_ACTCMPBD_ZERO|PWM_2_GENB_ACTLOAD_ONE;	//0x80c;
	PWM1_2_LOAD_R = PWM_ZERO;											// 4KHz at SYSCLK = 16MHz (2000-1);
	PWM1_2_CMPA_R = PWM_ZERO - 1;										//1900;
	PWM1_2_CMPB_R = PWM_ZERO - 1;										//1900;
	PWM1_3_CTL_R = 0;
	PWM1_3_GENA_R = PWM_3_GENA_ACTCMPAD_ZERO|PWM_3_GENA_ACTLOAD_ONE;	//0x8c;
	PWM1_3_GENB_R = PWM_3_GENB_ACTCMPBD_ZERO|PWM_3_GENB_ACTLOAD_ONE;	//0x80c;
	PWM1_3_LOAD_R = PWM_ZERO; 											// 4KHz at SYSCLK = 16MHz (2000-1);
	PWM1_3_CMPA_R = PWM_ZERO - 1;										//1499;
	PWM1_3_CMPB_R = PWM_ZERO - 1;										//1499;
	PWM1_1_CTL_R = PWM_1_CTL_ENABLE;									//1;
	PWM1_2_CTL_R = PWM_2_CTL_ENABLE;									//1;
	PWM1_3_CTL_R = PWM_3_CTL_ENABLE;									//1;
//	PWM1_ENABLE_R = PWM_ENABLE_PWM7EN|PWM_ENABLE_PWM6EN|PWM_ENABLE_PWM5EN|PWM_ENABLE_PWM4EN|PWM_ENABLE_PWM3EN|PWM_ENABLE_PWM2EN;	//0xe0;
	PWM1_ENABLE_R = PWM_ENABLE_PWM5EN|PWM_ENABLE_PWM4EN;	//0xe0;
*/
	ipl |= pwm_init();

	// init ADC
	adc_init();
	ipl |= IPL_ADCINIT;

	// init QEI
	SYSCTL_RCGCQEI_R = SYSCTL_RCGCQEI_R1|SYSCTL_RCGCQEI_R0;			// enable clock to qei1/0
	GPIO_PORTC_AFSEL_R |= ENC1A|ENC1B;					// enable alt fn
	GPIO_PORTD_AFSEL_R |= ENC0A|ENC0B;					// enable alt fn
	GPIO_PORTC_PCTL_R &= ~(GPIO_PCTL_PC6_M|GPIO_PCTL_PC5_M);							// PB4 = port pin for IC
	GPIO_PORTC_PCTL_R |= (GPIO_PCTL_PC6_PHB1|GPIO_PCTL_PC5_PHA1);
	GPIO_PORTD_PCTL_R &= ~(GPIO_PCTL_PD7_M|GPIO_PCTL_PD6_M);							// PB4 = port pin for IC
	GPIO_PORTD_PCTL_R |= (GPIO_PCTL_PD7_PHB0|GPIO_PCTL_PD6_PHA0);
	QEI0_CTL_R = QEI_CTL_RESMODE|QEI_CTL_CAPMODE;				// cap mode = both edges, 0 = pha only
	QEI0_POS_R = 0x8000;							// 0x8000 = 0, 0x8001 = +1, 0x7fff = -1, ...
	QEI0_MAXPOS_R = 0x0000ffff;
	QEI1_CTL_R = QEI_CTL_RESMODE|QEI_CTL_CAPMODE;
	QEI1_POS_R = 0x8000;
	QEI1_MAXPOS_R = 0x0000ffff;
	QEI0_CTL_R = QEI_CTL_ENABLE;
	QEI1_CTL_R = QEI_CTL_ENABLE;
//	read position:
//	x = QEI0_POS_R;
//	rot dir:
//	dir = QEI0_STAT_R | QEI_STAT_DIRECTION; // 0 = fwd, 1 = reverse
//	dir = QEI0_STAT_R | QEI_STAT_ERROR; // 0 = OK, 1 = error in gray code

	// init EEPROM
	ipl |= eeprom_init();
	return ipl;
}

//*****************************************************************************
// hib_init()
//  initializes the HIB peripheral
//	init_switch == 0, turns on HIB osc only
//	else, remainder of HIB init (only allowed if timer interrupts enabled)
//
//*****************************************************************************
U16 hib_init(U8 init_switch){
//	volatile uint32_t ui32Loop;
//	U16	ipl = 0;

/*	if(!init_switch){
	    SYSCTL_RCGCHIB_R |= 0x01;
	    ui32Loop = HIB_CTL_R;							// dummy read
		if(!(ui32Loop & HIB_CTL_CLK32EN)){				// if CLK32EN == 0, this is the first POC, turn on HIB osc
		    HIB_IM_R = HIB_IM_WC;						// enable WC mask
		    if((ui32Loop & HIB_CTL_WRC) == 0){
		    	ipl = IPL_HIBERR;						// if WC set, then there is an HIB error
		    }else{
				HIB_CTL_R = HIB_CTL_CLK32EN;			// enable HIB clock
		    }
		}else{
			ipl = IPL_HIBINIT;							// init was completed on previous power cycle
		}
	}else{
		wait(1500);										// wait 1500ms for HIB osc to start
		while(!(HIB_CTL_R & HIB_CTL_WRC));				// make sure WC is clear
		HIB_CTL_R = HIB_CTL_PINWEN | HIB_CTL_CLK32EN | HIB_CTL_VBATSEL_2_1V;	// enable /WAKE control
		while(!(HIB_CTL_R & HIB_CTL_WRC));				// wait for WC to clear
		ipl = IPL_HIBINIT;								// set init complete
	}*/
	return 0; //ipl;
}
