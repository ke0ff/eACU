/********************************************************************
 ************ COPYRIGHT (c) 2023 by ke0ff, Taylor, TX   *************
 *
 *  File name: init.h
 *
 *  Module:    Control
 *
 *  Summary:   defines and global declarations for main.c
 *  			Also defines GPIO pins, timer constants, and other
 *  			GPIO system constants
 *
 *******************************************************************/

#include "typedef.h"
#include <stdint.h>

#ifndef INIT_H
#define INIT_H
#endif

//-----------------------------------------------------------------------------
// Global Constants
//-----------------------------------------------------------------------------

#define SYSCLKL 10000L
#define PIOCLK	(16000000L)			// internal osc freq (in Hz)
#define EXTXTAL           			// un-comment if external xtal is used
									// define EXTXTAL #def to select ext crystal
									// do not define for int osc
#ifdef EXTXTAL
#define XTAL 1
#define XTAL_FREQ	SYSCTL_RCC_XTAL_20MHZ	// set value of external XTAL
#define SYSCLK	(50000000L)			// sysclk freq (bus clk)
#else
#define XTAL 0
#define SYSCLK	PIOCLK				// sysclk freq (bus clk) same as PIOCLK
#endif

#define OSC_LF 4            		// osc clock selects
#define OSC_HF 0
#define OSC_EXT 1

#define SEC10MS    10           	// timer constants (ms)
#define SEC33MS    33
#define SEC50MS    50
#define SEC75MS    74
#define SEC100MS  100
#define SEC250MS  250
#define SEC500MS  500
#define SEC750MS  750
#define SEC1     1000
#define ONESEC   SEC1
#define SEC2     2000
#define SEC3     3000
#define SEC5     5000
#define SEC10   10000
#define SEC15   15000
#define SEC30   30000
#define SEC60   60000
#define SEC300 300000L
#define	ONEMIN	(SEC60)
#define	REG_WAIT_DLY 200			// 200ms wait limit for register action
#define RESP_SAMP SEC100MS			// sets resp rate

// timer definitions
#define TIMER1_PS 31				// prescale value for timer1
#define	TIMER1_FREQ	9600			// timer1 intr freq
#define TIMER3_ILR 0xffff			// timer 3 interval (24 bit)
#define TIMER3_PS 0xff
//#define TIMER1_PS 32
#define TIMER2_PS 32
#define	TPULSE	(100L)				// in usec
#define TMIN	(((SYSCLK / 100) * TPULSE)/10000L)	// minimum pulse width

// Port A defines
#define TXD0			0x01		// out		uart0
#define RXD0			0x02		// in		uart0
#define UART0_TXDIR		0x04		// out		RS485 TX enable
//#define 			0x08		// in
//#define 			0x10		// in
//#define 			0x20		// in
#define SCL				0x40		// out		i2c
#define SDA				0x80		// i/o		i2c
#define PORTA_DIRV		(TXD0|SCL|UART0_TXDIR)
#define	PORTA_DENV		(TXD0|RXD0|UART0_TXDIR|SCL|SDA)
#define	PORTA_PURV		(0)
#define	PORTA_DFLT		(0)

// Port B defines
#define RXD1			0x01		// in		uart1
#define TXD1			0x02		// out		uart1
#define MDATA4			0x04		// in		T3CCP0
#define nPTT2b			0x08		// in		SPARE0	T3CCP1
#define ENC2A			0x10		// in		T1CCP0
#define ENC2B			0x20		// in		T1CCP1
#define PTT7K			0x40		// out		SPARE1
#define PTTHM			0x80		// in
#define PORTB_DIRV		(TXD1|PTT7K)
#define	PORTB_DENV		(RXD1|TXD1|MDATA4|nPTT2b|ENC2A|ENC2B|PTT7K|PTTHM)
#define	PORTB_PURV		(MDATA4|PTTHM)

// Port C defines
#define SPARE2			0x10		// out
#define ENC1A 			0x20		// in		qei1A
#define ENC1B 			0x40		// in		qei1B
#define nMIC2EN 		0x80		// out
#define PORTC_DIRV		(SPARE2|nMIC2EN)
#define	PORTC_DENV		(SPARE2|ENC1A|ENC1B|nMIC2EN)
#define	PORTC_PURV		(0)

// Port D defines
#define ENC3A			0x01		// in
#define ENC3B			0x02		// in
#define PTTb			0x04		// out	SPARE3
#define SPARE4			0x08		// out
#define n7KDEN			0x10		// out
#define HMICEN			0x20		// out
#define ENC0A			0x40		// in		qei0A
#define ENC0B			0x80		// in		qei0B
#define PORTD_DIRV		(PTTb|SPARE4|n7KDEN|HMICEN)
#define	PORTD_DENV		(ENC3A|ENC3B|PTTb|SPARE4|n7KDEN|HMICEN|ENC0A|ENC0B)
#define	PORTD_PURV		(0)

// Port E defines
/*#define KADDR0			0x01		// out
#define KADDR1			0x02		// out
#define KADDR2			0x04		// out*/
#define	TUN_GRN			0x01		// out		GPIO
#define	TUN_RED			0x02		// out		GPIO
#define	SPARE5			0x08		// anin		AIN0
#define LED1			0x10		// out		M1PWM2	{debug RESP LED}
#define LED2			0x20		// out		M1PWM3	{dial BL}
#define PORTE_DIRV		(TUN_GRN|TUN_RED|LED1|LED2)
#define	PORTE_DENV		(TUN_GRN|TUN_RED|LED1|LED2)
#define	PORTE_PURV		(0)
// keypad defines
/*#define	KB_ADDR_M		(KADDR2|KADDR1|KADDR0)		// mask for kb row addr vector
#define	KB_COL_M		0 //(KCOL3|KCOL2|KCOL1|KCOL0)	// mask for kb col 1of4
#define	KB_NOKEY		0xff //(KCOL3|KCOL2|KCOL1|KCOL0)	// no keypressed semaphore
#define	KP_DEBOUNCE_DN	10			// 10 ms of keypad debounce
#define	KP_DEBOUNCE_UP	25			// 25 ms of keypad debounce*/

// Port F defines
#define LED3			0x01		// out		M1PWM4	{? LEDs}
#define LED4			0x02		// out		M1PWM5	(heartbeat LED}
#define LED5			0x04		// out		M1PWM6	{meter-face LED}
#define LED6			0x08		// out		M1PWM7	{? LED}
#define SPARE6			0x10		// out		(T2CCP0)
#define PORTF_DIRV		(LED3|LED4|LED5|LED6|SPARE6)
#define	PORTF_DENV		(LED3|LED4|LED5|LED6|SPARE6)

//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------

#ifndef MAIN_C
extern U16	app_timer1ms;		// app timer
extern U16	xm_timer;			// xmodem timer
extern U16	ccmd_timer;			// ccmd timer
extern char	bchar;				// global bchar storage
extern char	swcmd;				// global swcmd storage
extern S8	handshake;			// xon/xoff enable
extern S8	xoffsent;			// xoff sent
#endif

// system error flag defines
#define	PTT_TIMEOUT_ERR	0x00000080		// ic7k ptt ACU timeout
#define	ENC_2_STATE_ERR	0x00000100		// encoder 2 state error
#define	ENC_2_ISR_ERR	0x00000200		// encoder 2 ISR error
#define	ENC_3_STATE_ERR	0x00000400		// encoder 3 state error
#define	ENC_3_ISR_ERR	0x00000800		// encoder 3 ISR error
#define	HM_DATA_ERR		0x00001000		// HM-151 data error (not valid keycode)

#define	NOP				FALSE			// no-operation flag.  Passed to functions that have the option to perform an action or return a status
#define	CLR				TRUE			// perform read-and-clear operation flag.  Passed to functions that have the option to perform read status and clear
#define	ACU_LOOP_TIME	5				// (ms) min rate for repeat ACU commands
#define	KEY_NULL		'~'			// null chr for HMD keycode LUT
#define	ENC0_CHNG		0x01
#define	ENC1_CHNG		0x02
#define	ENC2_CHNG		0x04
#define	ENC3_CHNG		0x08
#define	KEY_CHNG		0x10
#define	KEYH_CHNG		0x20
#define	KEYHM_CHNG		0x40
#define	HM_1STKEY		0x02			// HM-151 data bit that indicates initial keypress
#define	HM_FNKEY		0x08			// HM-133 data bit that indicates fn key mode
#define	HM_DTMF			0x04			// HM-133 data bit that indicates DTMF key mode
#define	HM_PTT			0x01			// HM-133 data bit that indicates PTT 1st press
#define	PTT_TX			';'				// HM-133 PTT TX keycode
#define	PTT_RX			':'				// HM-133 PTT RX keycode
#define KEYP_IDLE		0x00			// keypad ISR state machine state IDs
#define KEYP_DBDN		0x01
#define KEYP_PRESSED	0x02
#define KEYP_HOLD		0x03
#define KEYP_DBUP		0x04
#define	KEY_PR_FL		0x01			// key-pressed bit field
#define	KEY_HOLD_FL		0x02			// key-hold bit field
#define KEY_HOLD_TIME	SEC1			// keypad hold timer value (~~ 2sec)
#define HMKEY_HOLD_CNT	40				// hm-151 keypad hold timer value (~~ 2sec)


//-----------------------------------------------------------------------------
// main.c Fn prototypes
//-----------------------------------------------------------------------------

void Init_Device(void);
char process_IO(U8 flag);
void process_ACU(U8 flag);
void  process_chg(U8 chg, char* buf, U8* key_mem, U8* keyh_mem);
U8 get_status(U8* keyh_mem);
void set_acu_loop(U8 value);
U8 set_pttmode(U8 value);

void waitpio(U16 waitms);
void wait(U16 waitms);
void wait2(U16 waitms);
U16 getipl(void);
U32 get_syserr(U8 opr);
U8 wait_reg0(volatile uint32_t *regptr, uint32_t clrmask, U16 delay);
U8 wait_reg1(volatile uint32_t *regptr, uint32_t setmask, U16 delay);

U8 got_key(void);
U8 not_key(U8 flag);
char get_key(void);
U8 got_hmd(void);
S32 get_hmd(void);
char get_hmcode(U32 keym);
U32 get_t3captim(U8 ptr); // debug fn

void set_pos0(U16 opr);
U16 get_pos0(void);
U8 get_encstat0(U8 opr);
void set_pos1(U16 opr);
U16 get_pos1(void);
U8 get_encstat1(U8 opr);
void set_pos2(U16);
U16 get_pos2(void);
U8 get_encstat2(U8 opr);
void set_pos3(U16);
U16 get_pos3(void);
U8 get_encstat3(U8 opr);
void encoder_init(void);
void warm_reset(void);
U32 free_run(void);

void gpiob_isr(void);
void gpiod_isr(void);
void Timer3_ISR(void);
void Timer2_ISR(void);

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------
