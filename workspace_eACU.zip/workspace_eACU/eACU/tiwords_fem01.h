// TI LPC Female Word Data
// data bit reversed, v1.00
// formatted for C

extern U8*	WTHE;

extern U8*	WTIME;

extern U8*	WIS;

extern U8*	WA_M;

extern U8*	WP_M;

extern U8*	WOH;

extern U8*	WOCLK;

extern U8*	WONE;

extern U8*	WTWO;

extern U8*	WTHREE;

extern U8*	WFOUR;

extern U8*	WFIVE;

extern U8*	WSIX;

extern U8*	WSEVEN;

extern U8*	WEIGHT;

extern U8*	WNINE;

extern U8*	WTEN;

extern U8*	W11;

extern U8*	W12;

extern U8*	W13;

extern U8*	W14;

extern U8*	W15;

extern U8*	W16;

extern U8*	W17;

extern U8*	W18;

extern U8*	W19;

extern U8*	W20;

extern U8*	W30;

extern U8*	W40;

extern U8*	W50;

extern U8*	WGOOD;

extern U8*	WMORN;

extern U8*	WAFTR;

extern U8*	WEVENG;

extern U8*	PAUSE;

