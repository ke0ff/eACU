/********************************************************************
 ************ COPYRIGHT (c) 2023 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  This is the main code file for the Ersatz ACU (eACU) application.
 *
 *  Project scope revision history:
 *    <VERSION 0.0>
 *    12-01-22 jmh:  Creation Date - Copied source from HFB project
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    06-12-23 jmh:  Added support for tuner status LEDs (RED and GREEN). A status message from the HFB will
 *    					drive updates to the PORTE outputs (b0 = green, b1 = red).
 *    					2 stop bits to serial outputs from UART1.
 *    					"TUx" sets the leds: x=0:both off, x=1:GRN, x=2:RED, x=3:GRN+RED
 *    				 Removed keypad defines and scanning code.  Reassigned PE[1:0] to drive tuner status LEDs
 *    12-01-22 jmh:  creation date
 *
 *******************************************************************/

//-----------------------------------------------------------------------------
// main.c
//  Interfaces keypad/encoders to ACU
//  UART0 is used for debug I/O.
//
//  Debug CLI is a simple maintenance/debug port (via UART0) with the following core commands:
//		VERS - interrogate SW version.
//		See "cmd_fn.c" for CLI details
//
//	Uses GPIO to drive scan decoder and scan inputs for a 4x8 keypad matrix.
//		The KADDR[2:0] outputs feed an HC138 MUX that drives 8, active low outputs.
//		KCOL[3:0] is an input nybble that will show a low when a key is closed and the
//		scanning address line for that row goes low.
//		Timer2 drives KADDR and reads KCOL.  These signals and activity timers feed into
//		a state machine that qualifies and buffers matrix key-presses.
//
//  Interrupt Resource Map:
//		Timer3 int		HM-151 serial data capture.  Feeds decoded data to the hm_buf[] array.
//		Timer1 int 		n/u
//		Timer2 int		GP app timers, drives "respiration" PWM output
//		UART0 			host debug CLI serial port (via the ICDI USB<->SERIAL circuit)
//		UART1			ACU command port (RS-232)
//		QEI0			main encoder (0), non-ISR, drives periph regs
//		QEI1			cmd encoder (1), non-ISR, drives periph regs
//		I2C				(opt) temp sense & SEEPROM
//		M1PWM			LEDs and opt. tone
//		GPIO edge		ENC 2 & 3, edge intrpts to decode encoder pulses
//
//  I/O Resource Map:
//      See "init.h"
//
//	SW: Basic functions:
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
// compile defines

#define MAIN_C
#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include <stdio.h>
#include <string.h>
#include "init.h"
#include "typedef.h"
#include "version.h"
#include "serial.h"
#include "cmd_fn.h"
#include "tiva_init.h"
#include "I2C0.h"
#include "adc.h"
#include "eeprom.h"
#include "ccmd.h"
#include "pwm.h"

//-----------------------------------------------------------------------------
// Definitions
//-----------------------------------------------------------------------------

//  see init.h for main #defines
#define	MAX_REBUF	4		// max # of rebufs
#define	MAX_BARS	7		// max # of led bars
#define	GETS_INIT	0xff	// gets_tab() static initializer signal
#define DAC_LDAC 20			// dac spi defines
#define DAC_PWRUP 21
#define DAC_CLR 22

//-----------------------------------------------------------------------------
// Local Variables
//-----------------------------------------------------------------------------

// Processor I/O assignments
//bitbands
#define DUT_ON  (*(volatile uint32_t *)(0x40058000 + (0x04 * 4)))
#define DUT_OFF (*(volatile uint32_t *)(0x40058000 + (0x08 * 4)))
#define DUT_SCK (*(volatile uint32_t *)(0x40058000 + (0x10 * 4)))
#define DUT_D   (*(volatile uint32_t *)(0x40058000 + (0x20 * 4)))
#define DUT_Q   (*(volatile uint32_t *)(0x40058000 + (0x40 * 4)))
#define DUT_CS  (*(volatile uint32_t *)(0x40058000 + (0x80 * 4)))

//-----------------------------------------------------------------------------
// Global variables (extern conditionals are in init.h)
//-----------------------------------------------------------------------------
U16		acu_timer;						// acu data pacing timer
U16		xm_timer;						// xmodem timer
U16		ccmd_timer;						// ccmd timer
U16		hmd_timer;						// HM151 data idle timeout timer
char	bchar;							// break character trap register - traps ESC ascii chars entered at terminal
char	swcmd;							// software command flag
S8		handshake;						// xon/xoff enable
S8		xoffsent;						// xoff sent

//-----------------------------------------------------------------------------
// Local variables in this file
//-----------------------------------------------------------------------------
U32		abaud;							// 0 = 115.2kb (the default)
U8		iplt2;							// timer2 ipl flag
U16		waittimer;						// gp wait timer
U8		debounceHM_timer;				// debounce#1 timer
U32		free_32;						// free-running ms timer
U16		hmkey_timer;					// key timer
U8		ptt7k_timer;					// ACU activity timer for PTT (2.55 sec upper limit)
S8		err_led_stat;					// err led status
U8		idx;
U16		ipl;							// initial power on state
#define	ENC_UPDATE	0x80				// update flag
#define	STATE_ENCA0	0					// encoder state labels
#define	STATE_ENCA1	1
#define	STATE_ENCB0	2
#define	STATE_ENCB1	3
U8		enc2_state;						// encoder 2 state reg
U8		enc3_state;						// encoder 3 state reg
U8		enc2_flag;						// encoder 2 update flag
U8		enc3_flag;						// encoder 3 update flag
U16		encpos2;						// encoder 2 pos
U16		encpos3;						// encoder 3 pos
U16		encreg0;						// encoder 0 reg (last sampled value..used to determine if enc has changed)
U16		encreg1;						// encoder 1 reg
U16		encreg2;						// encoder 2 reg
U16		encreg3;						// encoder 3 reg
U8		hm_tptr;						// HM-151 key buffer tail ptr
U8		hm_hptr;						// HM-151 key buffer head ptr
#define	HM_START	0x01
#define	HM_ERROR	0x02
#define	HM_BUFMAX	32					// HM-151 buffers and working regs
U32		hm_buf[HM_BUFMAX];
U8		hm_status_buf[HM_BUFMAX];
U8		hm_ctptr;						// capture buf tail ptr
U8		hm_chptr;						// capture buf head ptr
U32		hm_cap_buf[HM_BUFMAX];
#define KBD_ERR 0x01
#define KBD_BUFF_END 4
S8		kbd_buff[KBD_BUFF_END];			// keypad data buffer
U8		kbd_hptr;						// keypad buf head ptr
U8		kbd_tptr;						// keypad buf tail ptr
U8		kbd_stat;						// keypad buff status
U8		kbdn_flag;						// key down or hold
U8		kbup_flag;						// key released
U32		sys_error_flags;				// system error flags
U8		debug_i;
U8		acu_loop_time_reg;				// holds acu loop value
U8		ptt_mode;						// ptt update mode (process_io)

// HM-151 code LUT arrays:
#define	MAX_KEY	25						// # keys on HM-151
#define	MAX_KEY_133	23					// # keys on HM-133
//	HM-133: there are actually 25 keys, but two of them act as modifiers
//	  (func and dtmf) and do not send a key code.  The keys have different
//	  labeling, but each key is in roughly the same position with the same
//	  code.  However, many keys are labeled differently from the HM-151.
//	  The uACU should use the following key map:
//		Key code	Function
//		  M			F2
//		  V			F1
//		  X			Band change
//		  T			MR (and MW with persistent press)
//		  L			VFO
//
// HM-133 function key return set.  '%' and '!' are placekeepers to keep
//	alignment with the key_addr[] array.  These codes should never be sent
//	by an HM-133.  HM-151 doesn't have a FUNC mode, so it will never send
//	any of these codes.
char fnkey_code[] = { 'p',   'o',   'n',   'k',   'm',   'l',   'j',  '%',
					  '!',   'a',   'b',   'c',   'q',   'd',   'e',   'f',
					  'r',   'g',   'h',   'i',   's',   '+',   '`',   '$',
					  't',   '\0' };
// Normal mode keycodes for HM-151 and HM-133 (see above for HM-133 notes)
char key_code[] = { 'L',   'T',   'X',   '/',   'V',   'M',   '\\',  'F',
					'G',   '1',   '2',   '3',   'A',   '4',   '5',   '6',
					'B',   '7',   '8',   '9',   'C',   '*',   '0',   '#',
					'D',   '\0' };
// serial key codes less the func/dtmf/1stkey modifier nybble.
U16 key_addr[] =  {0x0b02,0x1302,0x2302,0x2202,0x0a02,0x1202,0x2002,0x1002,
				   0x0802,0x0b82,0x1382,0x2382,0x4382,0x0982,0x1182,0x2182,
				   0x4182,0x0a82,0x1282,0x2282,0x4282,0x0882,0x1082,0x2082,
				   0x4082,0x0000};

// respiration LED intensity profile LUT:
#define	R_STEP	((PWM_ZERO-PWM_MAX)/64)
U16 resp_profile[] =  { 0xff,    0,    0,    0,    0,    0,    0,    0,    0,
						   0,    0,    0,    0,    0,    0,    0,    0,    0,
						0x08, 0x0f, 0x1d, 0x27, 0x2a, 0x2d, 0x31, 0x34, 0x38,
						0x3c, 0x40, 0x46, 0x4c, 0x52, 0x58, 0x5d, 0x63, 0xff };

//-----------------------------------------------------------------------------
// Local Prototypes
//-----------------------------------------------------------------------------

void Timer_Init(void);
void Timer_SUBR(void);
char *gets_tab(char *buf, char *save_buf[3], int n);
char kp_asc(U8 keycode);

//*****************************************************************************
// main()
//  The main function runs a forever loop in which the main application operates.
//	Prior to the loop, Main performs system initialization, boot status
//	announcement, and main polling loop.  The loop also calls CLI capture/parse fns.
//	The CLI maintains and processes re-do buffers (4 total) that are accessed by the
//	TAB key.  Allows the last 4 valid command lines to be recalled and executed
//	(after TAB'ing to desired recall command, press ENTER to execute, or ESC to
//	clear command line).
//	Autobaud rate reset allows user to select alternate baudarates after reset:
//		115,200 baud is default.  A CR entered after reset at 57600, 38400,
//		19200, or 9600 baud will reset the system baud rate and prompt for user
//		acceptance.  Once accepted, the baud rate is frozen.  If rejected, baud rate
//		returns to 115200.  The first valid command at the default rate will also
//		freeze the baud rate.  Once frozen, the baud rate can not be changed until
//		system is reset.
//*****************************************************************************
int
main(void)
{
	volatile uint32_t ui32Loop;
//	uint32_t i;
//    uint8_t	tempi;			// tempi
    char	buf[80];			// command line buffer
    char	rebuf0[80];			// re-do buffer#1
    char	rebuf1[80];			// re-do buffer#2
    char	rebuf2[80];			// re-do buffer#3
    char	rebuf3[80];			// re-do buffer#4
    char	got_cmd;			// first valid cmd flag (freezes baud rate)
    U8		argn;				// number of args
    char*	cmd_string;			// CLI processing ptr
    char*	args[ARG_MAX];		// ptr array into CLI args
    char*	rebufN[4];			// pointer array to re-do buffers
    U16		offset;				// srecord offset register
    U16		cur_baud;			// current baud rate
    U8		fault_found;		// fault detected flag
    volatile U8		trapi = 1;

    fault_found = FALSE;								// only trap one fault-restart
	got_cmd = FALSE;
	offset = 0;
	cur_baud = 0;
//	iplt3 = 1;											// init timer3
    iplt2 = 1;											// init timer1
    ipl = proc_init();									// initialize the processor I/O
    do{													// outer-loop (do forever, allows soft-restart)
        rebufN[0] = rebuf0;								// init CLI re-buf pointers
    	rebufN[1] = rebuf1;
    	rebufN[2] = rebuf2;
    	rebufN[3] = rebuf3;
    	while(iplt2);									// wait for timer to finish intialization
    	wait(200);										// else, pad a bit of delay for POR to settle..
    	I2C_Init();										// init I2C system
    	dispSWvers(); 									// display reset banner
    	wait(10);										// a bit of delay..
    	rebuf0[0] = '\0';								// clear cmd re-do buffers
    	rebuf1[0] = '\0';
    	rebuf2[0] = '\0';
    	rebuf3[0] = '\0';
    	bcmd_resp_init();								// init bcmd response buffer
    	wait(10);										// a bit more delay..
    	hm_tptr = 0;									// init hmd rx regs
    	hm_hptr = 0;
    	hmd_timer = 0;
    	ptt7k_timer = 0;
    	GPIO_PORTB_DATA_R &= ~PTT7K;					// set PTT7K in-active
    	GPIO_PORTD_DATA_R &= ~PTTb;						// set PTTb in-active
    	while(gotchr()) getchr();						// clear serial input in case there was some POR garbage
    	gets_tab(buf, rebufN, GETS_INIT);				// initialize gets_tab()
    	process_IO(0xff);								// init process_io
    	set_acu_loop(0xff);								// init loop time
        set_stat(0xff, 0x00);							// init LED levels
#define LEVL 8
        set_stat(2, 0);									// enable resp led
        set_stat(3, 1);									// enable resp led
        set_stat(4, 1);									// enable resp led
        set_stat(5, 0);									// enable resp led
        set_stat(6, 0);									// enable resp led
        set_pwm(2, LEVL);									// enable resp led
        set_pwm(3, LEVL);									// enable resp led
//        set_pwm(4, LEVL);									// enable resp led
//        set_pwm(5, LEVL);									// enable resp led
//        set_pwm(6, LEVL);									// enable resp led
//        while(trapi);
    //	sprintf(buf,"STAT: %08x",last_stat);			// debug display
    //	puts0(buf);
    	// GPIO init
    	//...
//    	swcmd = 0;										// init SW command
    	// main loop
        do{
    		putchar_b(XON);
    		buf[0] = '\0';
    		putss("eacu>");										// prompt
    		cmd_string = gets_tab(buf, rebufN, 80); 			// get cmd line & save to re-do buf
    		if(!got_cmd){										// if no valid commands since reset, look for baud rate change
    			if(cur_baud != abaud){							// abaud is signal from gets_tab() that indicates a baud rate change
    				if(set_baud(abaud)){						// try to set new baud rate
    					puts0("");								// move to new line
    					dispSWvers();							// display reset banner & prompt to AKN new baud rate
    					while(gotchr()) getchr();				// clear out don't care characters
    					putss("press <Enter> to accept baud rate change: ");
    					while(!gotchr());						// wait for user input
    					puts0("");								// move to new line
    					if(getchr() == '\r'){					// if input = CR
    						cur_baud = abaud;					// update current baud = new baud
    						got_cmd = TRUE;						// freeze baud rate
    					}else{
    						set_baud(0);						// input was not a CR, return to default baud rate
    						cur_baud = abaud = 0;
    					}
    				}else{
    					abaud = cur_baud;						// new baud rate not valid, ignore & keep old rate
    				}
    			}else{
    				got_cmd = TRUE;								// freeze baud rate (@115.2kb)
    			}
    		}
    		argn = parse_args(cmd_string,args);					// parse cmd line
    		if(x_cmdfn(argn, args, &offset)) got_cmd = TRUE;	// process cmd line, set got_cmd if cmd valid
    		if((NVIC_FAULT_STAT_R) && !fault_found){			// test for initial fault
    	        puts1("FLT\n");									// fault message
    			swcmd = SW_ESC;									// abort to restart
    		}
        }while(swcmd != SW_ESC);
        swcmd = 0;
/*    	NVIC_DIS0_R = 0xFFFFFFFF;								// disable ISRs
    	NVIC_DIS1_R = 0xFFFFFFFF;
    	NVIC_DIS2_R = 0xFFFFFFFF;
    	NVIC_DIS3_R = 0xFFFFFFFF;
    	NVIC_DIS4_R = 0xFFFFFFFF;*/
    }while(1);
}

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// gets_tab puts serial input into buffer, UART0.
//-----------------------------------------------------------------------------
// Main loop for command line input.
// waits for a chr and puts into buf.  If 1st chr = \t, copy re-do buf into
//  cmdbuf and cycle to next re-do buf.  if more than n chrs input, nul term buf,
//	disp "line too long", and return.  if \n or \r, copy buf to save_buf & return
//  returns buf (pointer).
//	if n == 0xff, initialize statics and exit.
//
//	11/08/13: Modified to support 4 (MAX_REBUF) rolling cmd save buffers
//	11/15/13: Modified to support auto-baud detect on CR input
//		For the following, each bit chr shown is one bit time at 115200 baud (8.68056us).
//			s = start bit (0), p = stop bit (1), x = incorrect stop, i = idle (1), bits are ordered  lsb -> msb:
//	 the ascii code for CR = 10110000
//			At 115.2kb, CR = s10110000p = 0x0D
//
//			At 57.6 kb, CR = 00110011110000000011 (1/2 115.2kb)
//			@115.2, this is: s01100111ps00000001i = 0xE6, 0x80
//
//			At 38.4 kb, CR = 000111000111111000000000000111 (1/3 115.2kb)
//			@115.2, this is: s00111000p11111s00000000xxxiii = 0x1c, 0x00
//
//			At 19.2 kb, CR = 000000111111000000111111111111000000000000000000000000111111 (1/6 115.2kb)
//			@115.2, this is: s00000111piis00000111piiiiiiiis00000000xxxxxxxxxxxxxxxiiiiii = 0xE0, 0xE0, 0x00
//
//			At 9600 b,  CR = 000000000000111111111111000000000000111111111111111111111111000000000000000000000000000000000000000000000000111111111111 (1/12 115.2kb)
//			@115.2, this is: s00000000xxxiiiiiiiiiiiis00000000xxxiiiiiiiiiiiiiiiiiiiiiiiis00000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxiiiiiiiiiiii = 0x00, 0x00, 0x00
//
//		Thus, @ 57.6 kb, a CR = 0xE6 followed by 0x80
//			  @ 38.4 kb, a CR = 0x1C followed by 0x00
//			  @ 19.2 kb, a CR = 0xE0 followed by 0xE0 (plus a 0x00)
//			  @ 9600 b, a  CR = 0x00 followed by 0x00 (plus a 0x00)
//
//		NOTE: gets_tab is only used for command line input and thus should not
//		see non-ascii data under normal circumstances.

char *gets_tab(char *buf, char *save_buf[], int n)
{
	char	*cp;
	char	*sp;
	char	c;
	int		i = 0;
	static	U8   rebuf_num;
	static	U8	 last_chr;

//	if((rebuf_num >= MAX_REBUF) || (n == GETS_INIT)){ // n == 0xff is static initializer signal
	if(n == GETS_INIT){ // n == 0xff is static initializer signal
		rebuf_num = 0;									// init recall buffer pointer
		last_chr = 0xff;								// init to 0xff (not a valid baud select identifier chr)
		return buf;										// skip rest of Fn
	}
    cp = buf;
    sp = save_buf[rebuf_num];
    do{
        c = getch00();
        switch(c){
			case 0xE0:									// look for 19.2kb autoselect
				if(last_chr == 0xE0){
					abaud = 19200L;
					c = '\r';
				}
				break;

			case 0x00:									// look for 38.4kb or 9600b autoselect
				if(last_chr == 0x1C){
					abaud = 38400L;
					c = '\r';
				}else{
					if(last_chr == 0x00){
						abaud = 9600L;
						c = '\r';
					}
				}
				break;

			case 0x80:									// look for 57.6kb autoselect
				if(last_chr == 0xE6){
					abaud = 57600L;
					c = '\r';
				}
				break;

            case '\t':
				if(i != 0){								// if tab, cycle through saved cmd buffers
					do{
						i--;							// update count/point
						cp--;
						if((*cp >= ' ') && (*cp <= '~')){
							putchar0('\b');				// erase last chr if it was printable
							putchar0(' ');
							putchar0('\b');
						}
					}while(i != 0);
					cp = buf;							// just in case we got out of synch
				}
				//copy saved string up to first nul, \n, or \r
				if(--rebuf_num == 0xff){
					rebuf_num = MAX_REBUF - 1;
				}
				sp = save_buf[rebuf_num];
				while((*sp != '\0') && (*sp != '\r') && (*sp != '\n')){
					putdch(*sp);
					*cp++ = *sp++;
					i++;
				}
                break;

            case '\b':
            case 0x7f:
                if(i != 0){								// if bs & not start of line,
                    i--;								// update count/point
                    cp--;
                    if((*cp >= ' ') && (*cp <= '~')){
                        putchar0('\b');					// erase last chr if it was printable
                        putchar0(' ');
                        putchar0('\b');
                    }
                }
                break;

            case '\r':									// if cr, nul term buf & exit
            case '\n':									// if nl, nul term buf & exit
                i++;
                *cp++ = c;
                break;

            case ESC:									// if esc, nul buf & exit
                cp = buf;
                c = '\r';								// set escape condition
				i = 0;
                break;

            default:
                i++;
                *cp++ = c;								// put chr in buf
                putdch(c);								// no cntl chrs here
                break;
        }
		last_chr = c;									// set last chr
    } while((c != '\r') && (c != '\n') && (i < n));		// loop until c/r or l/f or buffer full
	if(i >= n){
		puts0("!! buffer overflow !!");
		*buf = '\0';									// abort line
	}else{
		puts0("");										// echo end of line to screen
		*cp = '\0';										// terminate command line
		if((*buf >= ' ') && (*buf <= '~')){				// if new buf not empty (ie, 1st chr = printable),
			strncpy(save_buf[rebuf_num], buf, n);		// copy new buf to save
			if(++rebuf_num >= MAX_REBUF) rebuf_num = 0;
		}
	}
    return buf;
}

//-----------------------------------------------------------------------------
// process_IO() processes system I/O
//-----------------------------------------------------------------------------
char process_IO(U8 flag){
#define	F2_HOLD_COUNT	16			// # of key msgs to trigger 2nd F2 function (approx 60ms/msg)

//			char buf[20];			// debug buff
//	static	U8	 f2_count;			// f2 hold down counter
//			U8	 i;					// temp U8
	volatile U32 ii;				// temp U32
	static	U8	ptt_edge;
			U8	j;					// temp
//	static	U16	tcnt;				// debug reg
//	static	U8	lcnt;				// debug reg

	// process IPL init
	if(flag == 0xff){							// perform init/debug fns
		ptt_mode = 0xff;						// force init
/*#define	TCNT_BASE	0x8000
		tcnt = TCNT_BASE;
		lcnt = 0;*/
	}
	switch(ptt_mode){
	case 0:
		j = GPIO_PORTB_DATA_R & nPTT2b;
		if(ptt_edge != j){
			ptt_edge = j;
			if(j) GPIO_PORTD_DATA_R &= ~PTTb;
			else GPIO_PORTD_DATA_R |= PTTb;
		}
		break;

	case 1:
		j = GPIO_PORTB_DATA_R & PTTHM;
		if(ptt_edge != j){
			ptt_edge = j;
			if(!j) GPIO_PORTD_DATA_R &= ~PTTb;
			else GPIO_PORTD_DATA_R |= PTTb;
		}
		break;

	default:
		process_CCMD(CCMD_IPL);
		process_ACU(0xff);
		ptt_edge = 1;
		ptt_mode = 0;
//		f2_count = 0;
		return 0;
	}
	process_CCMD(0);									// process CCMD inputs
	process_ACU(0);										// process ACU i/o
/*	// led debug
	if(!tcnt--){
		tcnt = TCNT_BASE;
		GPIO_PORTE_DATA_R = (GPIO_PORTE_DATA_R & 0xfc) | (lcnt++ & 0x03);
	}*/
	return swcmd;
}

//-----------------------------------------------------------------------------
// process_ACU() processes ACU serial output comms
// keypress message syntax: "k%@\r"
//	 % = the ASCII key character, @ = the modifier, "\r" = ASCII CR. modifiers are:
//		<space>: initial keydn
//		    "+": hold keydn (~~2 sec)
//		    ";": key release
// encoder message syntax: "enhhhh\r"
//			"n": enc# (0-3)
//		 "hhhh": ASCII 16b hex data
//		   "\r": ASCII CR.
//
// Minimum repeat rate is (100ms,default).  Messages only send if there is new
//	data.  POR sets encoder registers to 0x0000.
//-----------------------------------------------------------------------------
void process_ACU(U8 flag){

			char	buf[12];			// msg buff
	static	U8		last_events;		// last event register
	static	U8		key_mem;			// current key (used to determine 1st keypress)
	static	U8		keyh_mem;			// current hm-151 key (used to determine 1st keypress)
			U8		new_events;			// temp change flags
			U8		chg_events;			// temp uchar

	// process IPL init
	if(flag == 0xff){									// perform init
		key_mem = 0;
		keyh_mem = 0;
		last_events = 0;
		return;
	}
	new_events = get_status(&keyh_mem);					// get current status
	// this check allows new changes to get processed right away in case there is an input in-progress
	chg_events = (new_events ^ last_events) & new_events; // mask old events
	if(chg_events){
		process_chg(chg_events, buf, &key_mem, &keyh_mem); // process new events
		if(!last_events) acu_timer = (U16)acu_loop_time_reg;	// set loop timer only if nothing is in queue from last loop
		last_events |= new_events;						// update last change
		if(!acu_timer) acu_timer = 2;					// make sure we avoid a corner condition
	}
	// acu_timer paces output if an input is in constant motion (reduces bus activity)
	if((acu_timer == 0) && last_events){
		if(new_events){
			process_chg(new_events, buf, &key_mem, &keyh_mem); // process changes
			acu_timer = (U16)acu_loop_time_reg;				// reset loop timer
			last_events = new_events;
		}else{
			if(acu_timer == 0){
				last_events = 0;
			}
		}
	}
	return;
}

//-----------------------------------------------------------------------------
// process_chg() processes change flags
//-----------------------------------------------------------------------------
void  process_chg(U8 chg, char* buf, U8* key_mem, U8* keyh_mem){
	U8		i = '\0';			// temp uchar
	char	d;					// temp char
	U32		si;					// temp 32
	static	U8	hm_count;		// hm key repeat counter

	if(chg & ENC0_CHNG){							// enc0 changes detected
		get_encstat0(CLR);							// update encoder pos.
		sprintf(buf,"e0%04X",get_pos0());			// produce msg
		puts1(buf);									// send to UART
	}
	if(chg & ENC1_CHNG){							// enc1 changes detected
		get_encstat1(CLR);							// update encoder pos.
		sprintf(buf,"e1%04X",get_pos1());			// produce msg
		puts1(buf);									// send to UART
	}
	if(chg & ENC2_CHNG){							// enc2 changes detected
		get_encstat2(CLR);							// update encoder pos.
		sprintf(buf,"e2%04X",get_pos2());			// produce msg
		puts1(buf);									// send to UART
	}
	if(chg & ENC3_CHNG){							// enc3 changes detected
		get_encstat3(CLR);							// update encoder pos.
		sprintf(buf,"e3%04X",get_pos3());			// produce msg
		puts1(buf);									// send to UART
	}
	if(chg & KEY_CHNG){								// process key pad change
		if(kbup_flag){
			if(*key_mem){
				sprintf(buf,"k%c;",*key_mem);		// produce msg
				puts1(buf);							// send to UART
			}
			kbup_flag = 0;							// key release event, clear flags
			kbdn_flag = 0;
			*key_mem = '\0';
		}else{
			d = get_key();							// key press event
			if(d){
				sprintf(buf,"k%c ",d);				// produce msg
				puts1(buf);							// send to UART
			}
			*key_mem = d;							// save new key to mem.
		}
	}
	if(chg & KEYH_CHNG){							// key hold
		if(*key_mem){
			sprintf(buf,"k%c+",*key_mem);			// produce msg
			puts1(buf);								// send to UART
		}
	}
	if(chg & KEYHM_CHNG){
		if(debounceHM_timer == 0){					// process no-key from HM-151
			if(!(GPIO_PORTD_DATA_R & n7KDEN)){		// if ic7k not selected:
				if((*keyh_mem != KEY_NULL) && (*keyh_mem != 0)){
					sprintf(buf,"k%c;",*keyh_mem);	// construct hold key string
					puts1(buf);						// send to UART
				}
				*keyh_mem = 0;						// if no key, clear current key mem.
			}
		}
		si = get_hmd();								// get hm-151 data word
		d = get_hmcode(si);							// do key-code lookup
		i = '\0';
		if(si & HM_1STKEY){
			i = d;									// if 1st keypress, accept character
			hm_count = HMKEY_HOLD_CNT;				// set key-hold counter
		}
		if(d == PTT_TX){
			sprintf(buf,"k%c ",d);					// construct PTT=tx key string
			puts1(buf);								// send to UART
		}
		if(d == PTT_RX){
			sprintf(buf,"k%c;",d);					// construct PTT=rx key string
			puts1(buf);								// send to UART
		}
//		if(i == 'f'){								// process HM-151 F2 key
//			GPIO_PORTD_DATA_R ^= n7KDEN;			// if initial key, toggle mic status
//		}
		if(!(GPIO_PORTD_DATA_R & n7KDEN)){			// if ic7k not selected:
			if(i != KEY_NULL){
				debounceHM_timer = 100;				// reset loss-of-key detect timer
				if(i && (*keyh_mem == 0)){			// if mic data is not null AND key mem is null:
					*keyh_mem = i;					// save key to mem
					sprintf(buf,"k%c ",d);			// construct first key string
					puts1(buf);						// send to UART
				}else{
					if(hm_count != 0){
						if(--hm_count == 0){
							sprintf(buf,"k%c+",d);	// construct hold key string
							puts1(buf);				// send to UART
						}
					}
				}
//			}else{
//				*keyh_mem = i;						// save key to mem
			}
		}
	}
}

//-----------------------------------------------------------------------------
// get_status() returns true if:
//	* any encoder change
//	* got_key == true OR kbdn_flag != 0
//	* got_hm == true
//-----------------------------------------------------------------------------
U8 get_status(U8* keyh_mem){
	U8	rtn = 0;

	if(get_encstat0(NOP)) rtn |= ENC0_CHNG;
	if(get_encstat1(NOP)) rtn |= ENC1_CHNG;
	if(get_encstat2(NOP)) rtn |= ENC2_CHNG;
	if(get_encstat3(NOP)) rtn |= ENC3_CHNG;
	if(got_key()) rtn |= KEY_CHNG;
	//if keyup AND keydn, then it is a key released event
	if(kbdn_flag && kbup_flag) rtn |= KEY_CHNG;
	if(kbdn_flag & KEY_HOLD_FL){
		kbdn_flag &= ~KEY_HOLD_FL;
		rtn |= KEYH_CHNG;
	}
	if(got_hmd()) rtn |= KEYHM_CHNG;
	if((debounceHM_timer == 0) && (*keyh_mem != KEY_NULL)) rtn |= KEYHM_CHNG;
	return rtn;
}

//-----------------------------------------------------------------------------
// set_pttmode() sets the value of the pttmode register
//	0 = PTTb follows ~/PTT2, PTT7K disabled
//	1 = PTTB follows ~/PTTHM, ccmds to drive PTT7K enabled
//	any other value returns the current setting with no changes
//-----------------------------------------------------------------------------
U8 set_pttmode(U8 value){

	if(value == 0x00) ptt_mode = 0;
	if(value == 0x01) ptt_mode = 1;
	return ptt_mode;
}

//-----------------------------------------------------------------------------
// set_acu_loop() sets the value of the acu loop timer
//	a value of 0xff forces the compile-time default to be stored
//-----------------------------------------------------------------------------
void set_acu_loop(U8 value){

	if(value == 0xff) acu_loop_time_reg = ACU_LOOP_TIME;
	else acu_loop_time_reg = value;
	return;
}

//-----------------------------------------------------------------------------
// waitpio() uses a dedicated ms timer to establish a defined delay (+/- 1LSB latency)
//	loops through process_IO during wait period.
//-----------------------------------------------------------------------------
void waitpio(U16 waitms){
//	U32	i;

//	i = 545 * (U32)waitms;
    waittimer = waitms;
//    for(;i!=0;i--);		// patch
    while(waittimer != 0) process_IO(0);
    return;
}

//-----------------------------------------------------------------------------
// wait() uses a dedicated ms timer to establish a defined delay (+/- 1LSB latency)
//-----------------------------------------------------------------------------
void wait(U16 waitms)
{
//	U32	i;

//	i = 545 * (U32)waitms;
    waittimer = waitms;
//    for(;i!=0;i--);		// patch
    while(waittimer != 0);
    return;
}

//-----------------------------------------------------------------------------
// wait2() does quick delay pace
//-----------------------------------------------------------------------------
void wait2(U16 waitms)
{
	U32	i;

	i = 10 * (U32)waitms;
    waittimer = waitms;
    for(;i!=0;i--);		// patch
//    while(waittimer != 0);
    return;
}

//-----------------------------------------------------------------------------
// wait_reg0() waits for (delay timer == 0) or (regptr* & clrmask == 0)
//	if delay expires, return TRUE, else return FALSE
//-----------------------------------------------------------------------------
U8 wait_reg0(volatile uint32_t *regptr, uint32_t clrmask, U16 delay){
	U8 timout = FALSE;

    waittimer = delay;
    while((waittimer) && ((*regptr & clrmask) != 0));
    if(waittimer == 0) timout = TRUE;
    return timout;
}

//-----------------------------------------------------------------------------
// wait_reg1() waits for (delay timer == 0) or (regptr* & setmask == setmask)
//	if delay expires, return TRUE, else return FALSE
//-----------------------------------------------------------------------------
U8 wait_reg1(volatile uint32_t *regptr, uint32_t setmask, U16 delay){
	U8 timout = FALSE;

    waittimer = delay;
    while((waittimer) && ((*regptr & setmask) != setmask));
    if(waittimer == 0) timout = TRUE;
    return timout;
}

//-----------------------------------------------------------------------------
// getipl() returns current ipl flags value
//-----------------------------------------------------------------------------
U16 getipl(void){

	return ipl;
}

//-----------------------------------------------------------------------------
// get_syserr() returns current system error flags value
//	if opr == true, clear flags
//-----------------------------------------------------------------------------
U32 get_syserr(U8 opr){

	if(opr) sys_error_flags = 0;
	return sys_error_flags;
}

//-----------------------------------------------------------------------------
// got_key() returns true if key is pressed.
//-----------------------------------------------------------------------------
U8 got_key(void){
	char	rtn = FALSE;	// return value

	if(kbd_hptr != kbd_tptr) rtn = TRUE;				// key in buffer means a key was pressed
	return rtn;
}

//-----------------------------------------------------------------------------
// not_key() returns true if key is released.  Optional flag clears released status
//-----------------------------------------------------------------------------
U8 not_key(U8 flag){
	char	rtn = FALSE;	// return value

	if(kbup_flag) rtn = TRUE;								// key release is detected
	if(flag) kbup_flag = FALSE;							// clear key_up if flag is true
	return rtn;
}

//-----------------------------------------------------------------------------
// get_key() returns keypad ASCII key or 0x00 if none
//-----------------------------------------------------------------------------
char get_key(void){
	char	rtn = '\0';	// return value
	U8		j;

	if(kbd_hptr != kbd_tptr){
		j = kbd_buff[kbd_tptr++];						// get keypad code
		if(kbd_tptr == KBD_BUFF_END){					// update buf ptr w/ roll-over
			kbd_tptr = 0;
		}
		rtn = kp_asc(j);								// get ASCII
	}
	return rtn;
}

//-----------------------------------------------------------------------------
// convert keycodes to ASCII
//	keycode = [xccc|caaa] c = column nybble (GND 1of4), a = row addr, x = don't
//	care (mask to 0).
//
// keypad LUT.  Keycode is constructed by converting 1of4 col code to 2 bit binary,
//	then left shifting 2 bits and combining the codes to create a continuous index
//	into the ASCII lookup table. NOTE: '@' is an invalid keypad code
#define	KBD_MAXROW		5	// max # rows in keypad scan (= last valid row# + 1)
#define	QCH '@'				// place-keeper character for un-used keypad matrix locations
							// This is an "illegal character" that should produce an error flag
							// if encountered by the downstream LRU
//				   col 0    1    2    3
char keypad_lut[] = { 'A', '3', '2', '1',	/* row 0 --\									*/
					  'B', '6', '5', '4',	/* row 1 ---\___4x4 keypad						*/
					  'C', '9', '8', '7',	/* row 2 ---/									*/
					  'D', '#', '0', '*',	/* row 3 --/									*/
					  '[', ']', '<', '>',	/* row 4 (encoder PBs)							*/
					  '{', '}', '^', QCH,	/* row 5 CW paddle buttons (left, right, PB)	*/
					  QCH, QCH, QCH, QCH,	/* row 6 ...@ is expansion place-keeper...		*/
					  QCH, QCH, QCH, QCH };	/* row 7										*/
//-----------------------------------------------------------------------------

char kp_asc(U8 keycode){
	U8	i;			// temp
	U8	col;		// temp
	char c = '\0';	// ascii temp, default to invalid char (null)

	col = keycode & 0x78;	// extract the column status
	switch(col){			// This switch converts column 1of4 (inverted) to 2b binary
		case 0x70:			// col 0 detected (PA2)
			i = 0;
			break;

		case 0x68:			// col 1 detected (PA3)
			i = 1;
			break;

		case 0x58:			// col 2 detected (PA4)
			i = 2;
			break;

		case 0x38:			// col 3 detected (PA5)
			i = 3;
			break;

		default:			// invalid column (no key, or more than one, pressed)
			i = 0xff;
			break;
	}
	if(i != 0xff){			// if valid, combine 2b col with 3b row to get 5b index
		i = i | ((keycode & 0x07) << 2);
		c = keypad_lut[i];	// lookup ASCII code
	}
	return c;
}

//-----------------------------------------------------------------------------
// got_hmd() returns true if HM-151 data buffer not empty
//-----------------------------------------------------------------------------
U8 got_hmd(void){
	U8	rtn = FALSE;

	if(hm_tptr != hm_hptr){
		rtn = TRUE;
	}
	return rtn;
}

//-----------------------------------------------------------------------------
// get_hmd() returns HM-151 data/status or -1 if no data
//-----------------------------------------------------------------------------
S32 get_hmd(void){
	S32	rtn = -1L;

	if(hm_tptr != hm_hptr){
		rtn = (S32)(hm_buf[hm_tptr] & 0x00ffffff) | ((S32)hm_status_buf[hm_tptr] << 24);
		if(++hm_tptr > (HM_BUFMAX-1)) hm_tptr = 0;
	}
	return rtn;
}

//-----------------------------------------------------------------------------
// get_t3captim() returns capture time data or 0 if no data
//-----------------------------------------------------------------------------
U32 get_t3captim(U8 ptr){
	U32	rtn = 0L;

	if(ptr > (HM_BUFMAX-1)){
		if(hm_ctptr != hm_chptr){
			rtn = hm_cap_buf[hm_ctptr++];
			if(hm_ctptr > (HM_BUFMAX-1)) hm_ctptr = 0;
		}
	}else{
		rtn = hm_cap_buf[ptr];
	}
	return rtn;
}

//-----------------------------------------------------------------------------
// get_hmcode() returns keycode or '~' if none
//-----------------------------------------------------------------------------
char get_hmcode(U32 keym){
	char	rtn = KEY_NULL;	// null return value
	char	c;				// temps
	U16		ii;
	U8		i;
	U8		kstat;

	kstat = (U8)keym & 0x0f;							// get key status
	ii = (U16)(keym >> 4);								// conv hm151/133 keymatrix to keyaddr (low nyb is status)
	if(ii == 0x0002){									// HM-133 PTT
		if(kstat & HM_PTT) rtn = PTT_TX;				// semicolon is TX
		else rtn = PTT_RX;									// colon is RX
	}else{
		if(ii != 0xffff){
			i = 0;
			do{
				if(kstat & HM_FNKEY){
					c = fnkey_code[i];					// look for match in fn LUT
				}else{
					c = key_code[i];					// look for match in normal LUT
				}
				if(ii == key_addr[i++]) rtn = c;
			}while((rtn == KEY_NULL) && key_addr[i]);	// loop exits when match or end of LUT
			if(rtn == KEY_NULL){
				sys_error_flags |= HM_DATA_ERR;
			}else{
				if(kstat & HM_DTMF){
					rtn |= 0x80;						// if DTMF, set hi bit
				}
			}
		}
	}
	return rtn;
}

//-----------------------------------------------------------------------------
// set_pos0
//-----------------------------------------------------------------------------
//
// sets encoder #0 position to new value.
//
void set_pos0(U16 opr){

	QEI0_POS_R = opr;
	encreg0 = opr;
	return;
}

//-----------------------------------------------------------------------------
// get_pos0
//-----------------------------------------------------------------------------
//
// returns encoder #0 reg.
//
U16 get_pos0(void){

	return QEI0_POS_R;
}

//-----------------------------------------------------------------------------
// get_encstat0
//-----------------------------------------------------------------------------
//
// returns true if encoder #0 position has changed since last time this fn was called.
//	if opr is true, update the compare reg.
//
U8 get_encstat0(U8 opr){
	U8	rtn = FALSE;
	U16	pos = QEI0_POS_R;

	if(pos != encreg0) rtn = TRUE;
	if(opr && rtn) encreg0 = pos;
	return rtn;
}

//-----------------------------------------------------------------------------
// set_pos1
//-----------------------------------------------------------------------------
//
// sets encoder #1 position to new value.
//
void set_pos1(U16 opr){

	QEI1_POS_R = opr;
	encreg1 = opr;
	return;
}

//-----------------------------------------------------------------------------
// get_pos1
//-----------------------------------------------------------------------------
//
// returns encoder #1 reg.
//
U16 get_pos1(void){

	return QEI1_POS_R;
}

//-----------------------------------------------------------------------------
// get_encstat1
//-----------------------------------------------------------------------------
//
// returns true if encoder #1 position has changed since last time this fn was called.
//	if opr is true, update the compare reg.
//
U8 get_encstat1(U8 opr){
	U8	rtn = FALSE;
	U16	pos = QEI1_POS_R;

	if(pos != encreg1) rtn = TRUE;
	if(opr && rtn) encreg1 = pos;
	return rtn;
}

//-----------------------------------------------------------------------------
// set_pos2
//-----------------------------------------------------------------------------
//
// sets encoder #2 reg.
//
void set_pos2(U16 pos){

	encpos2 = pos;
	return;
}

//-----------------------------------------------------------------------------
// get_pos2
//-----------------------------------------------------------------------------
//
// returns encoder #2 reg.
//
U16 get_pos2(void){

	return encpos2;
}

//-----------------------------------------------------------------------------
// get_encstat2
//-----------------------------------------------------------------------------
//
// returns encoder #2 status.
//
U8 get_encstat2(U8 opr){
	U8	rtn;

	NVIC_DIS0_R = NVIC_EN0_GPIOB;				// disable enc2 intrpt around these acesses
	rtn = enc2_flag;
	if(opr && rtn) enc2_flag = 0;
	NVIC_EN0_R = NVIC_EN0_GPIOB;				// re-enable
	return rtn;
}

//-----------------------------------------------------------------------------
// set_pos3
//-----------------------------------------------------------------------------
//
// sets encoder #3 reg.
//
void set_pos3(U16 pos){

	encpos3 = pos;
	return;
}

//-----------------------------------------------------------------------------
// get_pos3
//-----------------------------------------------------------------------------
//
// returns encoder #3 reg.
//
U16 get_pos3(void){

	return encpos3;
}

//-----------------------------------------------------------------------------
// get_encstat3
//-----------------------------------------------------------------------------
//
// returns encoder #3 status.
//
U8 get_encstat3(U8 opr){
	U8	rtn;

	NVIC_DIS0_R = NVIC_EN0_GPIOD;				// disable enc2 intrpt around these acesses
	rtn = enc3_flag;
	if(opr && rtn) enc3_flag = 0;
	NVIC_EN0_R = NVIC_EN0_GPIOD;				// re-enable
	return rtn;
}

//-----------------------------------------------------------------------------
// encoder_init
//-----------------------------------------------------------------------------
//
// encoder_init() initializes the GPIO quadrature encoder ISR.
//

void encoder_init(void){

	// init enc 2
	GPIO_PORTB_IM_R &= ~(ENC2A|ENC2B);					// disable interrupts
	encpos2 = 0;										// encoder pos = 0 to start
	enc2_flag = 0;										// init encoder update flag
	GPIO_PORTB_IS_R &= ~(ENC2A|ENC2B);					// edge sense
	GPIO_PORTB_IBE_R |= (ENC2A|ENC2B);					// both edges
	if(GPIO_PORTB_DATA_R & ENC2A){
		enc2_state = STATE_ENCA1;						// init state reg
	}else{
		enc2_state = STATE_ENCA0;						// init state reg
	}
	GPIO_PORTB_ICR_R = (ENC2A|ENC2B);					// pre-clear interrupts
	GPIO_PORTB_IM_R |= ENC2A;							// enable A interrupts
	NVIC_EN0_R = NVIC_EN0_GPIOB;

	// init enc 3
	GPIO_PORTD_IM_R &= ~(ENC3A|ENC3B);					// disable interrupts
	encpos3 = 0;										// encoder pos = 0 to start
	enc3_flag = 0;										// init encoder update flag
	GPIO_PORTD_IS_R &= ~(ENC3A|ENC3B);					// edge sense
	GPIO_PORTD_IBE_R |= (ENC3A|ENC3B);					// both edges
	if(GPIO_PORTD_DATA_R & ENC3A){
		enc3_state = STATE_ENCA1;						// init state reg
	}else{
		enc3_state = STATE_ENCA0;						// init state reg
	}
	GPIO_PORTD_ICR_R = (ENC3A|ENC3B);					// pre-clear interrupts
	GPIO_PORTD_IM_R |= ENC3A;							// enable A interrupts
	NVIC_EN0_R = NVIC_EN0_GPIOD;
    return;
}

//-----------------------------------------------------------------------------
// warm reset
//-----------------------------------------------------------------------------
//
// warm_reset() causes main() to re-start.
//

void warm_reset(void){
	swcmd = SW_ESC;				// trigger restart
}

//-----------------------------------------------------------------------------
// free_run
//-----------------------------------------------------------------------------
//
// free_run() returns value of free-running timer
//

U32 free_run(void){
	return free_32;				// return timer value
}

//-----------------------------------------------------------------------------
// gpiob_isr
//-----------------------------------------------------------------------------
//
// GPIO_PORTB isr, processes the rotary encoder for ENC2, inspired by E-load SW.
//		Uses flip-flop logic to bounce between A and B interrupts so that when
//		one phase generates an IRQ, the other phase will be the next enabled IRQ
//		and the phase that was the source of the IRQ is disabled.
//		The level of the A-PH sets the initial condx.  States are named by the level
//		of their corresponding phase.  States exit when an edge from the same phase
//		is detected, and they always exit to the opposite phase state.
//		Only A-PH states update encoder position (optional: both phases update...use
//		"UPDATE_ON_AB2" define).
//

// !!!ONLY ENABLE ONE OF THE FOLLOWING AT A TIME!!!
//#define	UPDATE_4PER_CYCLE2	// if defined, only count on ENCA0 state
#define	UPDATE_ON_AB2	1	// if defined, enable update on both phases of ENC2

void gpiob_isr(void)
{

	if((GPIO_PORTB_MIS_R & (ENC2A|ENC2B))){
		GPIO_PORTB_ICR_R = (ENC2A|ENC2B);				// clear int flags
		switch(enc2_state){
		// process encoder A cycle
		case STATE_ENCA0:
			if(GPIO_PORTB_DATA_R & ENC2B){			// if B = 1
				encpos2--;							// ccw
				enc2_flag |= ENC_UPDATE;
				enc2_state = STATE_ENCB1;
				GPIO_PORTB_IM_R &= ~ENC2A;			// enable B interrupts only
				GPIO_PORTB_IM_R |= ENC2B;
			}else{
				encpos2++;							// cw
				enc2_flag |= ENC_UPDATE;
				enc2_state = STATE_ENCB0;
				GPIO_PORTB_IM_R &= ~ENC2A;			// enable B interrupts only
				GPIO_PORTB_IM_R |= ENC2B;
			}
			break;

		case STATE_ENCA1:
			if(GPIO_PORTB_DATA_R & ENC2B){			// if B = 1
#ifndef UPDATE_4PER_CYCLE2
				encpos2++;							// cw
				enc2_flag |= ENC_UPDATE;
#endif
				enc2_state = STATE_ENCB1;
				GPIO_PORTB_IM_R &= ~ENC2A;			// enable B interrupts only
				GPIO_PORTB_IM_R |= ENC2B;
			}else{
#ifndef UPDATE_4PER_CYCLE2
				encpos2--;							// ccw
				enc2_flag |= ENC_UPDATE;
#endif
				enc2_state = STATE_ENCB0;
				GPIO_PORTB_IM_R &= ~ENC2A;			// enable B interrupts only
				GPIO_PORTB_IM_R |= ENC2B;
			}
			break;

		case STATE_ENCB0:
			if(GPIO_PORTB_DATA_R & ENC2A){			// if A = 1
#ifdef UPDATE_ON_AB2
				encpos2++;							// cw
				enc2_flag |= ENC_UPDATE;
#endif
				enc2_state = STATE_ENCA1;
				GPIO_PORTB_IM_R &= ~ENC2B;			// enable A interrupts only
				GPIO_PORTB_IM_R |= ENC2A;
			}else{
#ifdef UPDATE_ON_AB2
				encpos2--;							// ccw
				enc2_flag |= ENC_UPDATE;
#endif
				enc2_state = STATE_ENCA0;
				GPIO_PORTB_IM_R &= ~ENC2B;			// enable A interrupts only
				GPIO_PORTB_IM_R |= ENC2A;
			}
			break;

		// process encoder B cycle
		case STATE_ENCB1:
			if(GPIO_PORTB_DATA_R & ENC2A){			// if A = 1
#ifdef UPDATE_ON_AB2
				encpos2--;							// ccw
				enc2_flag |= ENC_UPDATE;
#endif
				enc2_state = STATE_ENCA1;
				GPIO_PORTB_IM_R &= ~ENC2B;			// enable A interrupts only
				GPIO_PORTB_IM_R |= ENC2A;
			}else{
#ifdef UPDATE_ON_AB2
				encpos2++;							// cw
				enc2_flag |= ENC_UPDATE;
#endif
				enc2_state = STATE_ENCA0;
				GPIO_PORTB_IM_R &= ~ENC2B;			// enable A interrupts only
				GPIO_PORTB_IM_R |= ENC2A;
			}
			break;

		default:
			// state error...re-init
			if(GPIO_PORTB_DATA_R & ENC2A){			// if A = 1
				enc2_flag = 0;
				enc2_state = STATE_ENCA1;
				GPIO_PORTB_IM_R &= ~ENC2B;			// enable A interrupts only
				GPIO_PORTB_IM_R |= ENC2A;
			}else{
				enc2_flag = 0;
				enc2_state = STATE_ENCA0;
				GPIO_PORTB_IM_R &= ~ENC2B;			// enable A interrupts only
				GPIO_PORTB_IM_R |= ENC2A;
			}
			// set encoder state error
			sys_error_flags |= ENC_2_STATE_ERR;
			break;
		}
	}else{
		GPIO_PORTB_IM_R &= (ENC2A|ENC2B);				// make sure other ints are masked
		// set GPIO ISR error
		sys_error_flags |= ENC_2_ISR_ERR;
	}
	return;
}

//-----------------------------------------------------------------------------
// gpiod_isr
//-----------------------------------------------------------------------------
//
// GPIO_PORTD isr, processes the rotary encoder for ENC3, inspired by E-load SW.
//		Uses flip-flop logic to bounce between A and B triggered interrupts so that
//		when one phase generates an IRQ, that phase's IRQ is disabled, and the other
//		phase is enabled.  Thus, the polarity of the edge on the target phase need
//		not be known, it is inferred from the previous level, and the opposite
//		phase level is sampled at a point where it should not be changing.  This
//		elliminates the need for debounce timers.
//
//		The level of the A-PH sets the initial condx.  States are named by the level
//		of their corresponding phase.  States exit when an edge from the same phase
//		is detected, and they always exit to the opposite phase state based on the.
//		of the opposite phase.  Only A-PH states update encoder position (optional:
//		both phases update...use "UPDATE_ON_AB3" define).
//

// !!!ONLY ENABLE ONE OF THE FOLLOWING AT A TIME!!!
#define	UPDATE_4PER_CYCLE3	// if defined, only count on ENCA0 state
//#define	UPDATE_ON_AB3	1	// if defined, enable update on both phases of ENC3

void gpiod_isr(void){

	if((GPIO_PORTD_MIS_R & (ENC3A|ENC3B))){
		GPIO_PORTD_ICR_R = (ENC3A|ENC3B);				// clear int flags
		switch(enc3_state){
		// process encoder A cycle
		case STATE_ENCA0:
			if(GPIO_PORTD_DATA_R & ENC3B){			// if B = 1
				encpos3--;							// ccw
				enc3_flag |= ENC_UPDATE;
				enc3_state = STATE_ENCB1;
				GPIO_PORTD_IM_R &= ~ENC3A;			// enable B interrupts only
				GPIO_PORTD_IM_R |= ENC3B;
			}else{
				encpos3++;							// cw
				enc3_flag |= ENC_UPDATE;
				enc3_state = STATE_ENCB0;
				GPIO_PORTD_IM_R &= ~ENC3A;			// enable B interrupts only
				GPIO_PORTD_IM_R |= ENC3B;
			}
			break;

		case STATE_ENCA1:
			if(GPIO_PORTD_DATA_R & ENC3B){			// if B = 1
#ifndef UPDATE_4PER_CYCLE3
				encpos3++;							// cw
				enc3_flag |= ENC_UPDATE;
#endif
				enc3_state = STATE_ENCB1;
				GPIO_PORTD_IM_R &= ~ENC3A;			// enable B interrupts only
				GPIO_PORTD_IM_R |= ENC3B;
			}else{
#ifndef UPDATE_4PER_CYCLE3
				encpos3--;							// ccw
				enc3_flag |= ENC_UPDATE;
#endif
				enc3_state = STATE_ENCB0;
				GPIO_PORTD_IM_R &= ~ENC3A;			// enable B interrupts only
				GPIO_PORTD_IM_R |= ENC3B;
			}
			break;

		// process encoder B cycle
		case STATE_ENCB0:
			if(GPIO_PORTD_DATA_R & ENC3A){			// if A = 1
#ifdef UPDATE_ON_AB3
				encpos3++;							// cw
				enc3_flag |= ENC_UPDATE;
#endif
				enc3_state = STATE_ENCA1;
				GPIO_PORTD_IM_R &= ~ENC3B;			// enable A interrupts only
				GPIO_PORTD_IM_R |= ENC3A;
			}else{
#ifdef UPDATE_ON_AB3
				encpos3--;							// ccw
				enc3_flag |= ENC_UPDATE;
#endif
				enc3_state = STATE_ENCA0;
				GPIO_PORTD_IM_R &= ~ENC3B;			// enable A interrupts only
				GPIO_PORTD_IM_R |= ENC3A;
			}
			break;

		case STATE_ENCB1:
			if(GPIO_PORTD_DATA_R & ENC3A){			// if A = 1
#ifdef UPDATE_ON_AB3
				encpos3--;							// ccw
				enc3_flag |= ENC_UPDATE;
#endif
				enc3_state = STATE_ENCA1;
				GPIO_PORTD_IM_R &= ~ENC3B;			// enable A interrupts only
				GPIO_PORTD_IM_R |= ENC3A;
			}else{
#ifdef UPDATE_ON_AB3
				encpos3++;							// cw
				enc3_flag |= ENC_UPDATE;
#endif
				enc3_state = STATE_ENCA0;
				GPIO_PORTD_IM_R &= ~ENC3B;			// enable A interrupts only
				GPIO_PORTD_IM_R |= ENC3A;
			}
			break;

		default:
			// state error...re-init
			if(GPIO_PORTD_DATA_R & ENC3A){			// if A = 1
				enc3_flag = 0;
				enc3_state = STATE_ENCA1;
				GPIO_PORTD_IM_R &= ~ENC3B;			// enable A interrupts only
				GPIO_PORTD_IM_R |= ENC3A;
			}else{
				enc3_flag = 0;
				enc3_state = STATE_ENCA0;
				GPIO_PORTD_IM_R &= ~ENC3B;			// enable A interrupts only
				GPIO_PORTD_IM_R |= ENC3A;
			}
			// set encoder state error
			sys_error_flags |= ENC_3_STATE_ERR;
			break;
		}
	}else{
		GPIO_PORTD_IM_R &= (ENC3A|ENC3B);
		// set GPIO ISR error
		sys_error_flags |= ENC_3_ISR_ERR;
	}
	return;
}

//-----------------------------------------------------------------------------
// Timer3_ISR
//-----------------------------------------------------------------------------
//
// Called when timer3A input time capture event is detected:
//	This event is rising edge from the HM-151 data line.  HM-151 data is a
//		serial format that features a 195us low followed by a 230us high
//		(logic "0") or a 415us high (logic "1").  NOTE: The data line is
//		inverted at the input of the MCU.  7 zeros plus a 750us low is a
//		sync pulse (start of a 2-word frame)
//
//	HM-151 Keys send bursts of 2 data words at a 43-60 ms rate (measured at
//		about 50 ms).
//
//	This timer measures the time between rising edges (as seen at MCU pin) and
//		determines if the transitions represent a 1, 0, or sync pulse.  An
//		application timer is used to establish a previous period of no edge
//		activity. (this resets the serial input state machine).
//		The messages are 19 bits plus a stop bit.  Since the timer looks for
//		falling edges, and bursts consist of two words, only the 1st word's
//		stop bit will be captured.  Thus, the first word after a long idle or
//		a sync pulse will count 20 bits until the data is captured.  The 2nd
//		word triggers a capture after only 19 bits.  This saves the expense
//		of configuring another timer ISR to establish the end of the 2nd word's
//		stop bit.
//		Once captured, the data word is stored to the FILO buffers (hm_buf[]
//		for data, hm_status_buf[] for status) for processing by the process loops.
//		NOTE: Data consumers must extract both the data and status before
//		updating the tail pointer.
//
//		Keycode matrix:
//		LOCK (L)	TUNER (T)	XFC (X)
//		0b020		13020		23020
//
//		upARROW (/)		V/M (V)	MW (M)
//		22020			0a020	12020
//
//		dnARROW (\)		F1 (F)	F2 (f)
//		20020			10020	08020
//
//		1		2		3		MODE (A)
//		0b820	13820	23820	43820
//
//		4		5		6		FIL  (B)
//		09820	11820	21820	41820
//
//		7		8		9		GENE (C)
//		0a820	12820	22820	42820
//
//		.		0		CE (#)	ENT  (D)
//		08820	10820	20820	40820

//-----------------------------------------------------------------------------

void Timer3_ISR(void)
{
	static	U32	dmask;			// data mask
	static	U32	hm_data;		// data register
	static	U8	hm_status;		// status register
	static	U32	last_edge;		// last edge capture (sign extended to 32 bits)
	static	U8	bit_count;		// count of # bits rcvd
	U8		temp;				// temp ptr reg
	U32		captim;				// capture time holding reg
	U32		captemp;			// capture time temp reg

	//bit time thresholds
#define	HMT_MIN		(220L * (SYSCLK/1000000L))		// minimum bit time
#define	HMT_0		(540L * (SYSCLK/1000000L))		// max "0" bit time
#define	HMT_1		(850L * (SYSCLK/1000000L))		// max "1" bit time
#define	HMT_SYNC	(1500L * (SYSCLK/1000000L))		// max SYNC bit time
#define	HMD_BURST_TO 3								// burst word timeout

	captim = TIMER3_TAR_R;							// grab time of edge
	TIMER3_ICR_R = TIMER_ICR_CAECINT;				// clear intr
	if(captim < last_edge){							// calc pulse duration (in SYSCLK tics)
		captemp = 0x1000000L - last_edge + captim;	// if rollover
	}else{
		captemp = captim - last_edge;				// normal timer progression
	}
	if(captemp < HMT_MIN) return;					// ignore if pulse too short
	last_edge = captim;								// save new edge
	if(hmd_timer == 0){								// look for LOS timeout
		// reset data & mask
		dmask = 0x01;								// reset data/status regs
		bit_count = 0;
		hm_data = 0;
		hm_status = 0;
		hmd_timer = HMD_BURST_TO;					// reset burst timer
	}else{
		hmd_timer = HMD_BURST_TO;					// reset 5ms timer
		if(captemp < HMT_0){						// check if pulse is a "0"
			dmask = dmask << 1;						// shift dmask...0 in data is implicit
			bit_count++;							// update bit count
		}else{
			if(captemp < HMT_1){					// check if pulse is a "1"
				hm_data |= dmask;					// place a "1" into the data reg
				dmask = dmask << 1;					// shift dmask
				bit_count++;						// update bit count
			}else{
				if(captemp < HMT_SYNC){ // if sync pulse (opt, && sync preamble),
					dmask = 0x01;					// reset data input registers (discard old data)
					hm_data = 0;
					bit_count = 0;
					hm_status |= HM_START;			// set start of frame
/*					if((!((hm_data >> (bit_count-7)) & 0x7F)) && (bit_count > 6)){
						if((!((hm_data >> (bit_count-7)) & 0x7F)) && (bit_count > 6)){
						hm_status |= HM_START;		// set start if proper sync
					}else{
						hm_status |= HM_ERROR;		// else set error
					}*/
				}else{
					hm_status |= HM_ERROR;			// else set error
				}
			}
		}
		if(bit_count == 20){						// if 20 bits, capture data & status
			temp = hm_hptr;							// save ptr in case we overflow
			hm_buf[hm_hptr] = hm_data;
			hm_status_buf[hm_hptr++] = hm_status;
			if(hm_hptr > (HM_BUFMAX-1)) hm_hptr = 0; // roll-over head pointer
			if(hm_hptr == hm_tptr) hm_hptr = temp;	// buffer overflow, don't advance head
			dmask = 0x01;							// reset data regs
			hm_data = 0;
			bit_count = 1;							// only look for 19 bits on the 2nd try
			hm_status = 0;
		}
	}
}

//-----------------------------------------------------------------------------
// Timer2_ISR
//-----------------------------------------------------------------------------
//
// Called when timer2 A overflows (NORM mode):
//	intended to update app timers @ 1ms per lsb
//	also drives RGB "I'm alive" LED.  The LED transitions through the color
//	wheel in a way that can be modified by the #defines below. RATE, PERIOD,
//	and START values may be adjusted to taylor the color transitions,
//	transition rate, and cycle period.
//
//-----------------------------------------------------------------------------

void Timer2_ISR(void){
#if (PWM_CH1 && PWM_CH5)
static	U16	prescale;				// prescales the ms rate to the LED update rate
//static	U16	period_counter;			// counts the LED cycle period (ms)
static	U8	resp_idx;				// running index into respiration table
static	U8	ping;					// ping/pong flag (controls direction of resp_idx count...0=up)
		U16	t2_temp;				// temp
		U32	t2_temp32;
#endif
//static	U8	keydb_tmr;
		U8	key_temp;				// keypad temp
static	U8	kp_state;				// keypad state machine reg
static	U8	key_addr;				// keypad row addr select (0-3)
static	U16	kphold_timer;			// keypad hold timer
static	U8	keybd_timer;			// keypad debounce timer

#define	PWM_RATE_RED	4			// delta duty cycle values (this is added/subtracted to/fr the DCreg every 10ms)
#define	LED_PERIOD		10000		// sets length of LED cycle (ms)

	GPIO_PORTD_DATA_R ^= SPARE4;			// toggle debug pin
	TIMER2_ICR_R = TIMER2_MIS_R;
/*	if(iplt2 || (++period_counter > LED_PERIOD)){	// if flag is set, perform ipl initialization
		prescale = 0;								// also, do this every LED cycle
		PWM1_1_CMPA_R = PWM_ZERO - 1;				// clear PWM compare regsiters, LED1
//		PWM1_1_CMPB_R = PWM_ZERO - 1;				// .. LED2
//		PWM1_2_CMPA_R = PWM_ZERO - 1;				// .. LED3
//		PWM1_2_CMPB_R = PWM_ZERO - 1;				// .. LED4
		PWM1_3_CMPA_R = PWM_ZERO - 1;				// .. LED5
//		PWM1_3_CMPB_R = PWM_ZERO - 1;				// .. LED6
		resp_idx = 1;
		ping = 0;
		period_counter = 0;
	}*/
	if(iplt2){										// if flag is set, perform ipl initialization
		iplt2 = 0;
		free_32 = 0;
		kp_state = KEYP_IDLE;
		kphold_timer = 0;
		key_addr = 0;
		kbdn_flag = 0;
		kbup_flag = 0;
#if (PWM_CH1 && PWM_CH5)
		prescale = 0;								// init resp led regs
		PWM1_1_CMPA_R = PWM_ZERO - 1;				// LED1
		PWM1_3_CMPA_R = PWM_ZERO - 1;				// LED5
		resp_idx = 1;
		ping = 0;
#endif
	}
	// state machine to process local keypad
	// kbdn_flag == true if key pressed (app needs to clear), also has "hold" flag that indicates
	//	that the key has been pressed for at least the KEY_HOLD time (app needs to clear)
	// kbup_flag == true if key is released (app needs to clear)
	// Row address to switch matrix is only advanced when there is no keypress (so, this alg. doesn't do
	// key rollover).
/*	key_temp = 0xff; //GPIO_PORTA_DATA_R; //& KB_COL_M;		// read keypad col bits
	switch(kp_state){
	default:
	case KEYP_IDLE:
		if(key_temp == KB_NOKEY){
			if(++key_addr > KBD_MAXROW) key_addr = 0; // advance key addr to next row
			GPIO_PORTE_DATA_R = (GPIO_PORTE_DATA_R & ~KB_ADDR_M) | (key_addr & KB_ADDR_M);
		}else{
			keybd_timer = KP_DEBOUNCE_DN;			// set debounce timer (dn)
			kp_state = KEYP_DBDN;						// advance state
		}
		break;

	case KEYP_DBDN:
		if(key_temp == KB_NOKEY){
			kp_state = KEYP_IDLE;					// false key, return to idle
		}else{
			if(--keybd_timer == 0){
				key_temp = (key_temp << 1) | (key_addr & KB_ADDR_M); //  construct composite key address = [ccc|caaa]
				kbdn_flag = KEY_PR_FL;				// set key pressed flag
				kbd_buff[kbd_hptr++] = key_temp;	// store key addr in buff
				if(kbd_hptr == KBD_BUFF_END){		// update buf ptr w/ roll-over
					kbd_hptr = 0;
				}
				if(kbd_hptr == kbd_tptr){			// flag buffer error
					kbd_stat |= KBD_ERR;
				}
				kphold_timer = KEY_HOLD_TIME;		// set hold timer (~~2 sec)
				kp_state = KEYP_PRESSED;			// advance state
			}
		}
		break;

	case KEYP_PRESSED:
		if(key_temp == KB_NOKEY){
			keybd_timer = KP_DEBOUNCE_UP;			// set debounce timer (up)
			kp_state = KEYP_DBUP;					// up debounce state
		}else{
			if(kphold_timer == 0){
				kbdn_flag |= KEY_HOLD_FL;			// set key-hold flag
				kp_state = KEYP_HOLD;				// hold state
			}else{
				kphold_timer -= 1;					// update hold timer
			}
		}
		break;

	case KEYP_HOLD:
		if(key_temp == KB_NOKEY){
			keybd_timer = KP_DEBOUNCE_UP;			// set debounce timer (up)
			kp_state = KEYP_DBUP;					// up debounce state
		}
		break;

	case KEYP_DBUP:
		if(key_temp != KB_NOKEY){
			kp_state = KEYP_PRESSED;				// false key up, return to pressed (if was hold, this will resolve)
		}else{
			if(--keybd_timer == 0){
				kbup_flag = 1;						// set key up flag
				kp_state = KEYP_IDLE;				// advance state
			}
		}
		break;
	}*/
	// process led1 resp. display
#if (PWM_CH1 && PWM_CH5)
	if(++prescale > RESP_SAMP){					// prescale sets PWM update period
		t2_temp = resp_profile[resp_idx];		// get next intensity value
		t2_temp32 = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)t2_temp / 100L) - 1L;
		kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)pwm_read(1) * (U32)pwm_read(MASTER_PWM) / 10000L) - 1L;
		if(t2_temp == 0xff){
			ping ^= 1;							// flip direction
		}else{
			PWM1_1_CMPA_R = (U16)t2_temp32;			// set LED1 PWM compare register (sets duty cycle)
			if(pwm_stat(5)){
				t2_temp32 = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)t2_temp * (U32)pwm_read(5) / 10000L) - 1L;
				PWM1_3_CMPA_R = (U16)t2_temp32;		// LED5 running
			}else{
				PWM1_3_CMPA_R = PWM_ZERO - 1;	// LED5 off
			}
		}
		if(ping) resp_idx -= 1;					// advance index
		else resp_idx += 1;						// retard index
		prescale = 0;
	}
#endif
	// process app timers
	free_32++;								// update large free-running timer
	if (acu_timer != 0){					// update acu app timer
		acu_timer--;
	}
	if (waittimer != 0){					// update wait timer
		waittimer--;
	}
	if (debounceHM_timer != 0){				// update debounce#1 timer
		debounceHM_timer--;
	}
	if (ccmd_timer != 0){					// update CCMD timer
		ccmd_timer--;
	}
	if (hmd_timer != 0){					// update HM-151 key timer
		hmd_timer--;
	}
	if (hmkey_timer != 0){					// update HM-151 keydn timer
		hmkey_timer--;
	}
	// process HM-151 PTT timeout
	if (ptt7k_timer != 0){					// update ptt timer
		if(--ptt7k_timer == 0){
			GPIO_PORTB_DATA_R &= ~PTT7K;	// set PTT in-active
			// set PTT timeout error
			sys_error_flags |= PTT_TIMEOUT_ERR;
		}
	}
	// process HM-151 PTT echo
	if(GPIO_PORTC_DATA_R & nMIC2EN){		// if HM-151 connected to ACU,
		if(GPIO_PORTB_DATA_R & PTTHM){	// echo nPTTHM to PTTb
			GPIO_PORTD_DATA_R |= PTTb;		// echo PTT in-active
		}else{
			GPIO_PORTD_DATA_R &= ~PTTb;		// echo PTT active
		}
	}else{									// hsMIC connected to ACU,
		if(GPIO_PORTB_DATA_R & nPTT2b){		// echo PTT2b to PTTb
			GPIO_PORTD_DATA_R &= ~PTTb;		// echo PTT in-active
		}else{
			GPIO_PORTD_DATA_R |= PTTb;		// echo PTT active
		}
	}
	GPIO_PORTD_DATA_R ^= SPARE4;			// toggle debug pin
}

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------

