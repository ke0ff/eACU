/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: pwm.h
 *
 *  Module:    Control
 *
 *  Summary:   defines and global declarations for pwm.c
 *
 *******************************************************************/

#include "typedef.h"
#include <stdint.h>

#ifndef INIT_H
#define INIT_H
#endif

//-----------------------------------------------------------------------------
// Global Constants
//-----------------------------------------------------------------------------

#define	MASTER_PWM	0

// PWM rate defines
#define	PWM_FREQ		10000L		// this is the PWM frequency in Hz
#define	PWM_DIV			2			// bit pattern for the PWM_DIV field in SYSCTL_RCC
									// 0 = /2,  1 = /4,  2 = /8,  3 = /16,
									// 4 = /32, 5 = /64, 6 = /64, 7 = /64
#define	PWM_DIVSR		8L			// = 2^(PWM_DIV + 1)
#define	PWM_ZERO		(SYSCLK/(PWM_DIVSR * PWM_FREQ)) // = 625  - the PWM "zero" point based on a 2000/8E6 PWM frequency
#define	PWM_MAX			(2L*PWM_ZERO/8L)				// = 156  - this is the max PWM counter value for the LED output

//////////////////////////////////////////////////////////////////////
// PWM port-pin enables
// enable these defines if PWM is to be assigned to a PF/PE port pin

#define	PE4_PWM		0		// "1" ==enable, else set to "0"
#define	PE5_PWM		0
#define	PF0_PWM		1
#define	PF1_PWM		1
#define	PF2_PWM		0
#define	PF3_PWM		0
#define	PF4_PWM		0
//////////////////////////////////////////////////////////////////////

#define	PE4_GPIO	(PE4_PWM << 4)		// LED1
#define	PE5_GPIO	(PE5_PWM << 5)		// LED2
#define	PF0_GPIO	(PF0_PWM << 0)		// LED3
#define	PF1_GPIO	(PF1_PWM << 1)		// LED4
#define	PF2_GPIO	(PF2_PWM << 2)		// LED5
#define	PF3_GPIO	(PF3_PWM << 3)		// LED6

// Defined channel ordinal list The "PWM_CHx" expansion will have a value of 0x00 if the
//	channel is not defined.  If defined, the expansion is a bitmask for the GPIO bit position
//	of the PWM output port pin.
#define	PWM_CH1		PE4_GPIO
#define	PWM_CH2		PE5_GPIO
#define	PWM_CH3		PF0_GPIO
#define	PWM_CH4		PF1_GPIO
#define	PWM_CH5		PF2_GPIO
#define	PWM_CH6		PF3_GPIO

// end PWM port pin enables

// Fn declares

U32 pwm_init(void);
void set_pwm(U8 pwmnum, U8 percent);
void set_stat(U8 lednum, U8 value);
U8 pwm_read(U8 pwmnum);
U8 pwm_stat(U8 pwmnum);
