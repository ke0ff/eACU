/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: pwm.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  Tiva PWM init/processing functions
 *
 *  This file compiles based on the GPIO selections "Pxy_PWM" ("x" is "E" or "F";
 *  "y" is 0-5).  Memory and GPIO are conserved if not used.
 *
 *  The PWM implementation has been tested driving LEDs in the 4-10 KHz PWM period.
 *
 *  pwm_init() initializes the PWM system
 *  set_pwm() sets the PWM level (in %) for a given channel
 *  set_stat() turns a channel on or off
 *  pwm_read() returns the % setting of a given channel
 *  pwm_stat() returns on/off status for a given channel
 *
 *******************************************************************/

#include "inc/tm4c123gh6pm.h"
#include "typedef.h"
#include "init.h"						// App-specific SFR Definitions
#include "tiva_init.h"
#include "pwm.h"

//=============================================================================
// local registers
#if	PE4_GPIO!=0
U8		led_1_on;						// led on regs (1/0)
U8		led_1_level;					// led level regs (0-100%)
U16		pwm1_reg;						// led pwm regs
#endif

#if	PE5_GPIO!=0
U8		led_2_on;
U8		led_2_level;
U16		pwm2_reg;
#endif

#if	PF0_GPIO!=0
U8		led_3_on;
U8		led_3_level;
U16		pwm3_reg;
#endif

#if	PF1_GPIO!=0
U8		led_4_on;
U8		led_4_level;
U16		pwm4_reg;
#endif

#if	PF2_GPIO!=0
U8		led_5_on;
U8		led_5_level;
U16		pwm5_reg;
#endif

#if	PF3_GPIO!=0
U8		led_6_on;
U8		led_6_level;
U16		pwm6_reg;
#endif

U8		pwm_master;						// led master level

//=============================================================================
// local Fn declarations

//=============================================================================

//-----------------------------------------------------------------------------
// init pwm periphs
//-----------------------------------------------------------------------------
//
//	PWM INIT -- SEE init.h for PWM port-pin enables
//	Enables/configures up to 6 PWM outputs from PE4/5 to PF0-3
U32 pwm_init(void){
	volatile uint32_t ui32Loop;

	SYSCTL_RCGCPWM_R |= SYSCTL_RCGCPWM_R1;
	ui32Loop = SYSCTL_RCGCPWM_R;										// delay a few cycles
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R5 | SYSCTL_RCGCGPIO_R4;
	ui32Loop = SYSCTL_RCGCGPIO_R;										// delay a few cycles

#if	PF0_PWM==1
	GPIO_PORTF_AFSEL_R |= PF0_GPIO;										// enable alt fn, PF0
	GPIO_PORTF_PCTL_R &= ~(GPIO_PCTL_PF0_M);
	GPIO_PORTF_PCTL_R |= (GPIO_PCTL_PF0_M1PWM4);
#endif

#if	PF1_PWM==1
	GPIO_PORTF_AFSEL_R |= PF1_GPIO;										// enable alt fn, PF1
	GPIO_PORTF_PCTL_R &= ~(GPIO_PCTL_PF1_M);
	GPIO_PORTF_PCTL_R |= (GPIO_PCTL_PF1_M1PWM5);
#endif

#if	PF2_PWM==1
	GPIO_PORTF_AFSEL_R |= PF2_GPIO;										// enable alt fn, PF2
	GPIO_PORTF_PCTL_R &= ~(GPIO_PCTL_PF2_M);
	GPIO_PORTF_PCTL_R |= (GPIO_PCTL_PF2_M1PWM6);
#endif

#if	PF3_PWM==1
	GPIO_PORTF_AFSEL_R |= PF3_GPIO;										// enable alt fn, PF3
	GPIO_PORTF_PCTL_R &= ~(GPIO_PCTL_PF3_M);
	GPIO_PORTF_PCTL_R |= (GPIO_PCTL_PF3_M1PWM7);
#endif

#if	PE4_PWM==1
	GPIO_PORTE_AFSEL_R |= PE4_GPIO;										// enable alt fn, PE4
	GPIO_PORTE_PCTL_R &= ~(GPIO_PCTL_PE4_M);
	GPIO_PORTE_PCTL_R |= (GPIO_PCTL_PE4_M1PWM2);
#endif

#if	PE5_PWM==1
	GPIO_PORTE_AFSEL_R |= PE5_GPIO;									// enable alt fn, PE5
	GPIO_PORTE_PCTL_R &= ~(GPIO_PCTL_PE5_M);
	GPIO_PORTE_PCTL_R |= (GPIO_PCTL_PE5_M1PWM3);
#endif

	SYSCTL_RCC_R = (SYSCTL_RCC_R & ~SYSCTL_RCC_PWMDIV_M) | (PWM_DIV << 17) | SYSCTL_RCC_USEPWMDIV;
	PWM1_1_CTL_R = 0;
	PWM1_1_LOAD_R = PWM_ZERO;											// 4KHz at SYSCLK = 16MHz (2000-1);

#if	PE4_PWM==1
	PWM1_1_GENA_R = PWM_1_GENA_ACTCMPAD_ZERO|PWM_1_GENA_ACTLOAD_ONE;
	PWM1_1_CMPA_R = PWM_ZERO - 1;										// PE4
#endif

#if	PE5_PWM==1
	PWM1_1_GENB_R = PWM_1_GENB_ACTCMPBD_ZERO|PWM_1_GENB_ACTLOAD_ONE;
	PWM1_1_CMPB_R = PWM_ZERO - 1;										// PE5
#endif

	PWM1_2_CTL_R = 0;
	PWM1_2_LOAD_R = PWM_ZERO;											// 4KHz at SYSCLK = 16MHz (2000-1);

#if	PF0_PWM==1
	PWM1_2_GENA_R = PWM_2_GENA_ACTCMPAD_ZERO|PWM_2_GENA_ACTLOAD_ONE;
	PWM1_2_CMPA_R = PWM_ZERO - 1;										// PF0
#endif
	#if	PF1_PWM==1
	PWM1_2_GENB_R = PWM_2_GENB_ACTCMPBD_ZERO|PWM_2_GENB_ACTLOAD_ONE;
	PWM1_2_CMPB_R = PWM_ZERO - 1;										// PF1
#endif

	PWM1_3_CTL_R = 0;
	PWM1_3_LOAD_R = PWM_ZERO; 											// 4KHz at SYSCLK = 16MHz (2000-1);
#if	PF2_PWM==1
	PWM1_3_GENA_R = PWM_3_GENA_ACTCMPAD_ZERO|PWM_3_GENA_ACTLOAD_ONE;
	PWM1_3_CMPA_R = PWM_ZERO - 1;										// PF2
#endif

#if	PF3_PWM==1
	PWM1_3_GENB_R = PWM_3_GENB_ACTCMPBD_ZERO|PWM_3_GENB_ACTLOAD_ONE;
	PWM1_3_CMPB_R = PWM_ZERO - 1;										// PF3
#endif

#if	(PE4_PWM==1)|(PE5_PWM==1)
	PWM1_1_CTL_R = PWM_1_CTL_ENABLE;
#endif

#if	(PF0_PWM==1)|(PF1_PWM==1)
	PWM1_2_CTL_R = PWM_2_CTL_ENABLE;
#endif

#if	(PF2_PWM==1)|(PF3_PWM==1)
	PWM1_3_CTL_R = PWM_3_CTL_ENABLE;
#endif

	PWM1_ENABLE_R = (PWM_ENABLE_PWM7EN&(PF3_PWM<<7))|
					(PWM_ENABLE_PWM6EN&(PF2_PWM<<6))|
					(PWM_ENABLE_PWM5EN&(PF1_PWM<<5))|
					(PWM_ENABLE_PWM4EN&(PF0_PWM<<4))|
					(PWM_ENABLE_PWM3EN&(PE5_PWM<<3))|
					(PWM_ENABLE_PWM2EN&(PE4_PWM<<2));

	return IPL_PWM1INIT;
}

//-----------------------------------------------------------------------------
// set pwm values
//-----------------------------------------------------------------------------
//
// set_pwm() sets the specified PWM to the percent value
//	pwmnum specifies the LED number.  LED 0 is the master setting.  This only sets the master,
//		it does not update any of the LED pwm registers.
//	percent is the percent level, 0 - 100.  If percent > 100, the value is unchanged
//		and the PWM settings are calculated based on stored led and master values
//

void set_pwm(U8 pwmnum, U8 percent){
	U32	kk;				// temp U32

	if(percent <= 100){
		switch(pwmnum){						// store level % value
		case 0:								// set master value
			pwm_master = percent;
			break;

#if	PE4_GPIO!=0
		case 1:
			led_1_level = percent;
			// calc PWM value in U32 to avoid overflow
			kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)led_2_level * (U32)pwm_master / 10000L) - 1L;
			// store PWM value
			pwm1_reg = (U16)kk;
			// update pwm if led is on
			if(led_1_on) PWM1_1_CMPA_R = pwm1_reg;
			break;
#endif
#if	PE5_GPIO!=0
		case 2:
			led_2_level = percent;
			kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)led_2_level * (U32)pwm_master / 10000L) - 1L;
			pwm2_reg = (U16)kk;
			if(led_2_on) PWM1_1_CMPB_R = pwm2_reg;
			break;
#endif
#if	PF0_GPIO!=0
		case 3:
			led_3_level = percent;
			kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)led_3_level * (U32)pwm_master / 10000L) - 1L;
			pwm3_reg = (U16)kk;
			if(led_3_on) PWM1_2_CMPA_R = kk;
			break;
#endif
#if	PF1_GPIO!=0
		case 4:
			led_4_level = percent;
			kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)led_4_level * (U32)pwm_master / 10000L) - 1L;
			pwm4_reg = (U16)kk;
			if(led_4_on) PWM1_2_CMPB_R = kk;
			break;
#endif
#if	PF2_GPIO!=0
		case 5:
			led_5_level = percent;
			kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)led_5_level * (U32)pwm_master / 10000L) - 1L;
			pwm5_reg = (U16)kk;
	//debug patch		if(led_5_on) PWM1_3_CMPA_R = kk;
			break;
#endif
#if	PF3_GPIO!=0
		case 6:
			led_6_level = percent;
			kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)led_6_level * (U32)pwm_master / 10000L) - 1L;
			pwm6_reg = (U16)kk;
			if(led_6_on) PWM1_3_CMPB_R = kk;
			break;
#endif
		default:
			break;
		}
	}
}

//-----------------------------------------------------------------------------
// set_stat() turns on/off the LED outputs
// if lednum == 0xff, do a POR init of the registers
// if lednum == 0x00, value = master %, reset all PWM values
//	else, value = 1/0 for on/off.  save to reg and update pwm reg to set on or off
//-----------------------------------------------------------------------------
void set_stat(U8 lednum, U8 value){

	if(lednum == 0xff){

#if	PE4_GPIO!=0
		led_1_on = 0;						// init registers all off
		led_1_level = 24;					// led level regs (0-100%)
		pwm1_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 24L / 100L) - 1L);
#endif
#if	PE5_GPIO!=0
		led_2_on = 0;						// init registers all off
		led_2_level = 24;					// led level regs (0-100%)
		pwm2_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 24L / 100L) - 1L);
#endif
#if	PF0_GPIO!=0
		led_3_on = 0;
		led_3_level = 16;
		pwm3_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 16L / 100L) - 1L);
#endif
#if	PF1_GPIO!=0
		led_4_on = 0;
		led_4_level = 50;
		pwm4_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 50L / 100L) - 1L);
#endif
#if	PF2_GPIO!=0
		led_5_on = 0;
		led_5_level = 22;
		pwm5_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 22L / 100L) - 1L);
#endif
#if	PF3_GPIO!=0
		led_6_on = 0;
		led_6_level = 99;
		pwm6_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 99L / 100L) - 1L);
#endif
		pwm_master = 99;					// led master level
		// led pwm regs
	}else{
		// process led settings
		if(value < 2){
			switch(lednum){
#if PE4_GPIO!=0
			case 1:
				led_2_on = value;
				if(led_2_on) PWM1_1_CMPB_R = pwm2_reg;
				else PWM1_1_CMPB_R = PWM_ZERO - 1;
				break;
#endif
#if PE5_GPIO!=0
			case 2:
				led_2_on = value;
				if(led_2_on) PWM1_1_CMPB_R = pwm2_reg;
				else PWM1_1_CMPB_R = PWM_ZERO - 1;
				break;
#endif
#if PF0_GPIO!=0
			case 3:
				led_3_on = value;
				if(led_3_on) PWM1_2_CMPA_R = pwm3_reg;
				else PWM1_2_CMPA_R = PWM_ZERO - 1;
				break;
#endif
#if PF1_GPIO!=0
			case 4:
				led_4_on = value;
				if(led_4_on) PWM1_2_CMPB_R = pwm4_reg;
				else PWM1_2_CMPB_R = PWM_ZERO - 1;
				break;
#endif
#if PF2_GPIO!=0
			case 5:
				led_5_on = value;
				if(!led_5_on) PWM1_3_CMPA_R = PWM_ZERO - 1;
				break;
#endif
#if PF3_GPIO!=0
			case 6:
				led_6_on = value;
				if(led_6_on) PWM1_3_CMPB_R = pwm6_reg;
				else PWM1_3_CMPB_R = PWM_ZERO - 1;
				break;
#endif
			default:
				break;
			}
		}
	}
}

//-----------------------------------------------------------------------------
// read PWM register values
//-----------------------------------------------------------------------------
//
// pwm_read() reads the specified PWM
//	pwmnum specifies the LED number.  LED 0 is the master setting.  This only sets the master,
//		it does not update any of the LED pwm registers.
//	return value of 0xff indicates that the pwmnum is invalid.
//

U8 pwm_read(U8 pwmnum){
	U8	i;				// temp U8

	switch(pwmnum){						// store level % value
	case 0:								// set master value
		i = pwm_master;
		break;

#if	PE4_GPIO!=0
	case 1:
		// fetch level
		i = led_1_level;
		break;
#endif
#if	PE5_GPIO!=0
	case 2:
		i = led_2_level;
		break;
#endif
#if	PF0_GPIO!=0
	case 3:
		i = led_3_level;
		break;
#endif
#if	PF1_GPIO!=0
	case 4:
		i = led_4_level;
		break;
#endif
#if	PF2_GPIO!=0
	case 5:
		i = led_5_level;
		break;
#endif
#if	PF3_GPIO!=0
	case 6:
		i = led_6_level;
		break;
#endif
	default:
		i = 0xff;
		break;
	}
	return i;
}

//-----------------------------------------------------------------------------
// read PWM on/off status
//-----------------------------------------------------------------------------
//
// pwm_stat() reads the specified PWM on/off status
//	pwmnum specifies the LED number.  LED 0 is the master setting.  This only sets the master,
//		it does not update any of the LED pwm registers.
//	return value of 0xff indicates that the pwmnum is invalid.
//

U8 pwm_stat(U8 pwmnum){
	U8	i;				// temp U8

	switch(pwmnum){						// store level % value
	case 0:								// set master value
		i = pwm_master;
		break;

#if	PE4_GPIO!=0
	case 1:
		// fetch level
		i = led_1_on;
		break;
#endif
#if	PE5_GPIO!=0
	case 2:
		i = led_2_on;
		break;
#endif
#if	PF0_GPIO!=0
	case 3:
		i = led_3_on;
		break;
#endif
#if	PF1_GPIO!=0
	case 4:
		i = led_4_on;
		break;
#endif
#if	PF2_GPIO!=0
	case 5:
		i = led_5_on;
		break;
#endif
#if	PF3_GPIO!=0
	case 6:
		i = led_6_on;
		break;
#endif
	default:
		i = 0xff;
		break;
	}
	return i;
}
